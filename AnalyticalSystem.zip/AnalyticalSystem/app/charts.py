# -*- coding: utf-8 -*-
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
import json

from app.core.db.db import load_vrp_summary


OUT_DIR = Path("results/analytics")

BASELINE_FILE = Path("cache/vrp_baseline_routes.json")
OPTIMIZED_FILE = Path("cache/optimized_routes_vrp.json")

def _load_json(path: Path):
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []


def generate_reports():
    """Генерує аналітичні графіки + графік оптимізації VRP."""

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    # ==========================================================
    # ГРАФІКИ ІСТОРІЇ VRP (із БД)
    # ==========================================================

    rows = load_vrp_summary()
    if rows:
        distance = [r[4] for r in rows]
        time = [r[5] for r in rows]
        stops = [r[6] for r in rows]

        # Histogram distance
        plt.figure(figsize=(6, 4))
        plt.hist(distance, bins=10)
        plt.title("Розподіл довжин маршрутів (км)")
        plt.xlabel("Дистанція, км")
        plt.ylabel("Кількість маршрутів")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(OUT_DIR / "dist_hist.png")
        plt.close()

        # Histogram time
        plt.figure(figsize=(6, 4))
        plt.hist(time, bins=10)
        plt.title("Розподіл тривалості маршрутів (хв)")
        plt.xlabel("Час, хв")
        plt.ylabel("Кількість маршрутів")
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(OUT_DIR / "time_hist.png")
        plt.close()

        # Scatter D vs T
        plt.figure(figsize=(6, 4))
        plt.scatter(distance, time)
        plt.title("Залежність часу від дистанції")
        plt.xlabel("Дистанція, км")
        plt.ylabel("Час, хв")
        plt.grid(True, alpha=0.4)
        plt.tight_layout()
        plt.savefig(OUT_DIR / "time_vs_distance.png")
        plt.close()

        # Scatter stops vs time
        plt.figure(figsize=(6, 4))
        plt.scatter(stops, time)
        plt.title("Залежність часу від кількості зупинок")
        plt.xlabel("Кількість зупинок")
        plt.ylabel("Час, хв")
        plt.grid(True, alpha=0.4)
        plt.tight_layout()
        plt.savefig(OUT_DIR / "time_vs_stops.png")
        plt.close()

        # Timeline
        plt.figure(figsize=(7, 4))
        plt.plot(distance, label="Дистанція (км)")
        plt.plot(time, label="Час (хв)")
        plt.title("Хронологія маршрутів")
        plt.xlabel("№ запуску")
        plt.ylabel("Значення")
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(OUT_DIR / "timeline_distance_time.png")
        plt.close()

    # ==========================================================
    # 6) ГРАФІК ДО / ПІСЛЯ ОПТИМІЗАЦІЇ (ТІЛЬКИ VRP)
    # ==========================================================

    baseline = _load_json(BASELINE_FILE)
    optimized = _load_json(OPTIMIZED_FILE)

    if not baseline or not optimized:
        print("⚠️ Немає baseline або optimized VRP — графік оптимізації не створено.")
        return True

    # Сумарні значення
    dist_before = sum(r.get("distance_km", 0) for r in baseline)
    time_before = sum(r.get("time_min", 0) for r in baseline)

    dist_after = sum(r.get("distance_km", 0) for r in optimized)
    time_after = sum(r.get("time_min", 0) for r in optimized)

    dist_delta_pct = (dist_before - dist_after) / max(dist_before, 1) * 100
    time_delta_pct = (time_before - time_after) / max(time_before, 1) * 100

    labels = ["Дистанція (км)", "Час (хв)"]
    before_vals = [dist_before, time_before]
    after_vals = [dist_after, time_after]

    x = [0, 1]

    plt.figure(figsize=(9, 5))

    plt.bar([i - 0.15 for i in x], before_vals, width=0.3, label="До оптимізації")
    plt.bar([i + 0.15 for i in x], after_vals, width=0.3, label="Після оптимізації")

    plt.xticks(x, labels)
    plt.ylabel("Загальні значення")

    plt.title(
        f"VRP: До / Після оптимізації\n"
        f"Дистанція: {dist_before:.2f} → {dist_after:.2f} км (−{dist_delta_pct:.1f}%)\n"
        f"Час:        {time_before:.2f} → {time_after:.2f} хв (−{time_delta_pct:.1f}%)"
    )

    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT_DIR / "vrp_optimization_comparison.png")
    plt.close()

    print("✅ Усі аналітичні графіки згенеровано.")

    return True
