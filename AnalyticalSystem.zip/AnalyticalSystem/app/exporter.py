# -*- coding: utf-8 -*-
from pathlib import Path
import csv, json
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

RESULTS = Path("results")
RESULTS.mkdir(exist_ok=True)

def export_stats_csv(stats: dict, path: Path | None = None):
    path = path or RESULTS/"vrp_stats.csv"
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["warehouse","vehicle","stops","distance_km","time_min"])
        for r in stats.get("routes", []):
            w.writerow([r["warehouse"], r["vehicle"], r["stops"], r["distance"], r["time"]])
    return path

def export_stats_json(stats: dict, path: Path | None = None):
    path = path or RESULTS/"vrp_stats.json"
    path.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
    return path

def export_summary_pdf(stats: dict, charts: list[Path] = None, path: Path | None = None):
    path = path or RESULTS/"summary.pdf"
    c = canvas.Canvas(str(path), pagesize=A4)
    W, H = A4
    y = H - 40
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, y, "Звіт оптимізації доставки")
    y -= 24
    c.setFont("Helvetica", 11)
    c.drawString(40, y, f"Тип: {stats.get('kind','VRP')}  |  Авто: {stats.get('vehicles',0)}")
    y -= 16
    c.drawString(40, y, f"Загальна відстань: {stats.get('distance',0)} км  |  Загальний час: {stats.get('time',0)} хв")
    y -= 24
    c.setFont("Helvetica-Bold", 12)
    c.drawString(40, y, "Маршрути:")
    y -= 18
    c.setFont("Helvetica", 10)
    for r in stats.get("routes", [])[:25]:
        line = f"- [{r['warehouse']}] авто #{r['vehicle']}: зупинок {r['stops']}, {r['distance']} км, {r['time']} хв"
        c.drawString(48, y, line); y -= 14
        if y < 120: c.showPage(); y = H - 40
    if charts:
        for img in charts:
            try:
                c.showPage()
                c.drawImage(str(img), 40, 160, width=W-80, height=400, preserveAspectRatio=True, anchor='c')
            except Exception:
                pass
    c.save()
    return path
