# -*- coding: utf-8 -*-
"""
Головний файл запуску аналітичної системи доставки.
"""

from app.ui.app_window import AppWindow


def main():
    """Стартова точка GUI застосунку."""
    app = AppWindow()
    app.mainloop()

if __name__ == "__main__":
    main()
