# -*- coding: utf-8 -*-
import customtkinter as ctk
from tkinter import ttk
import re


def convert_to_minutes(value: str):
    value = value.strip()
    if not value:
        return ""
    if value.isdigit():
        return int(value)
    if re.match(r"^\d{1,2}:\d{1,2}$", value):
        hh, mm = value.split(":")
        return int(hh) * 60 + int(mm)
    return value


class Sidebar(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, width=360, corner_radius=14)

        # ✅ Фіксована ширина + заборона розтягування
        self.configure(width=320)
        self.pack_propagate(False)

        # ✅ Правильне вирівнювання колонок
        self.grid_columnconfigure(0, weight=1)

        # ✅ Контейнер Sidebar
        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.grid(row=0, column=0, sticky="new")
        self.content.grid_columnconfigure(0, weight=1)

        # =============================
        # CALLBACKS
        # =============================
        self.on_add = None
        self.on_delete = None
        self.on_geocode = None
        self.on_route = None
        self.on_vrp = None
        self.on_cvrp = None
        self.on_vrptw = None
        self.on_eta_train = None
        self.on_eta_predict = None
        self.on_charts = None
        self.on_refresh = None
        self.on_clear_cache = None
        self.on_theme_toggle = None

        # =============================
        # UI BUILD
        # =============================
        row = 0

        def add_label(text):
            nonlocal row
            ctk.CTkLabel(self.content, text=text).grid(
                row=row, column=0, sticky="w", padx=10, pady=(10, 0)
            )
            row += 1

        def add_widget(widget):
            nonlocal row
            widget.grid(
                row=row, column=0, sticky="ew", padx=10, pady=4
            )
            row += 1

        # TITLE
        ctk.CTkLabel(
            self.content,
            text="Параметри доставки",
            font=("Segoe UI", 18, "bold")
        ).grid(row=row, column=0, pady=(8, 6), padx=10, sticky="ew")
        row += 1

        # ADDRESS
        add_label("Склад відправлення")
        self.warehouse_box = ctk.CTkComboBox(self.content, values=[])
        add_widget(self.warehouse_box)

        add_label("Місто призначення")
        self.city_box = ctk.CTkComboBox(self.content, values=[])
        add_widget(self.city_box)

        add_label("Населений пункт")
        self.settlement_box = ctk.CTkComboBox(self.content, values=[])
        add_widget(self.settlement_box)

        add_label("Адреса доставки")
        self.address_box = ctk.CTkComboBox(self.content, values=[])
        add_widget(self.address_box)

        # VEHICLES
        add_label("Кількість авто")
        self.vehicles_spin = ttk.Spinbox(
            self.content,
            from_=1,
            to=20,
            increment=1,
            width=12,
            justify="left"
        )
        self.vehicles_spin.set(1)
        add_widget(self.vehicles_spin)


        # =============================
        # ✅ DEFAULT VALUES INSERTED HERE
        # =============================

        # CVRP
        add_label("Вага (кг)")
        self.weight_box = ctk.CTkEntry(self.content, placeholder_text="0.0")
        self.weight_box.insert(0, "1.0")
        add_widget(self.weight_box)

        add_label("Обʼєм (м³)")
        self.volume_box = ctk.CTkEntry(self.content, placeholder_text="0.0")
        self.volume_box.insert(0, "1.0")
        add_widget(self.volume_box)

        # VRPTW
        add_label("TW Start (HH:MM або хв)")
        self.tw_start_box = ctk.CTkEntry(self.content, placeholder_text="09:00")
        self.tw_start_box.insert(0, "09:00")
        add_widget(self.tw_start_box)

        add_label("TW End (HH:MM або хв)")
        self.tw_end_box = ctk.CTkEntry(self.content, placeholder_text="18:00")
        self.tw_end_box.insert(0, "18:00")
        add_widget(self.tw_end_box)

        add_label("Service Time (хв)")
        self.service_box = ctk.CTkEntry(self.content, placeholder_text="10")
        self.service_box.insert(0, "10")
        add_widget(self.service_box)

        # ADD / DELETE
        btn_row = ctk.CTkFrame(self.content)
        btn_row.grid(row=row, column=0, sticky="ew", padx=10, pady=(10, 0))
        btn_row.grid_columnconfigure(0, weight=1)
        btn_row.grid_columnconfigure(1, weight=1)
        row += 1

        ctk.CTkButton(
            btn_row, text="Додати",
            command=self._add_with_time_conversion
        ).grid(row=0, column=0, sticky="ew", padx=(0, 6))

        ctk.CTkButton(
            btn_row, text="Видалити",
            fg_color="#aa3333",
            command=lambda: self.on_delete and self.on_delete()
        ).grid(row=0, column=1, sticky="ew")

        # GEO
        ctk.CTkButton(
            self.content, text="Геокодувати адреси",
            command=lambda: self.on_geocode and self.on_geocode()
        ).grid(row=row, column=0, sticky="ew", padx=10, pady=(10, 6))
        row += 1

        # ROUTING
        add_label("Маршрутизація")
        add_widget(ctk.CTkButton(
            self.content, text="Маршрут (OSRM → Google)",
            command=lambda: self.on_route and self.on_route()
        ))

        # VRP
        add_label("Оптимізація VRP")
        add_widget(ctk.CTkButton(self.content, text="Кластеризація + VRP",
                                 command=lambda: self.on_vrp and self.on_vrp()))
        add_widget(ctk.CTkButton(self.content, text="CVRP (по вазі / обʼєму)",
                                 command=lambda: self.on_cvrp and self.on_cvrp()))
        add_widget(ctk.CTkButton(self.content, text="VRPTW (часові вікна)",
                                 command=lambda: self.on_vrptw and self.on_vrptw()))

        # ETA
        add_label("ETA (Machine Learning)")
        add_widget(ctk.CTkButton(self.content, text="Навчити ETA",
                                 command=lambda: self.on_eta_train and self.on_eta_train()))
        add_widget(ctk.CTkButton(self.content, text="ETA для виділеного",
                                 command=lambda: self.on_eta_predict and self.on_eta_predict()))

        # ANALYTICS
        add_label("Аналітика")
        add_widget(ctk.CTkButton(self.content, text="Графіки оптимізації",
                                 command=lambda: self.on_charts and self.on_charts()))

        # SYSTEM
        add_widget(ctk.CTkButton(self.content, text="Оновити CSV",
                                 command=lambda: self.on_refresh and self.on_refresh()))
        add_widget(ctk.CTkButton(self.content, text="Очистити кеш",
                                 fg_color="#444444",
                                 command=lambda: self.on_clear_cache and self.on_clear_cache()))

        # THEME SWITCH
        self.theme_switch = ctk.CTkSwitch(
            self.content,
            text="Темний режим",
            command=lambda: self.on_theme_toggle and
                            self.on_theme_toggle(self.theme_switch.get())
        )
        add_widget(self.theme_switch)

    def _add_with_time_conversion(self):
        if not self.on_add:
            return
        self.tw_start_box_value = convert_to_minutes(self.tw_start_box.get())
        self.tw_end_box_value = convert_to_minutes(self.tw_end_box.get())
        self.service_box_value = self.service_box.get()
        self.on_add()
