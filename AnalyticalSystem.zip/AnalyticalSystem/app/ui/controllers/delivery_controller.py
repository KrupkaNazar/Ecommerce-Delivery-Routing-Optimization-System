# -*- coding: utf-8 -*-
import csv
from pathlib import Path
from tkinter import messagebox

from app.ui.table_panel import TablePanel
from app.ui.sidebar import Sidebar
from app.core.geocoder import Geocoder, save_cache

DATA_DIR = Path("data")
CACHE_FILE = Path("cache/locations.json")
WAREHOUSES_CSV = DATA_DIR / "warehouses.csv"
CITIES_CSV = DATA_DIR / "cities_ua.csv"
SETTLEMENTS_CSV = DATA_DIR / "settlements_ua.csv"
ADDRESSES_CSV = DATA_DIR / "delivery_addresses.csv"


# ------------------------------- LOADERS -------------------------------
def _load_list_from_csv(path: Path, col: int = 0):
    vals = []
    if path.exists():
        with open(path, encoding="utf-8") as f:
            r = csv.reader(f)
            for row in r:
                if not row:
                    continue
                if row[col].strip().lower() in ("city", "name"):
                    continue
                vals.append(row[col].strip())
    return sorted(list(dict.fromkeys(vals)))


def _load_settlements():
    mp = {}
    if SETTLEMENTS_CSV.exists():
        with open(SETTLEMENTS_CSV, encoding="utf-8") as f:
            r = csv.reader(f)
            for row in r:
                if len(row) < 2:
                    continue
                c, s = row[0].strip(), row[1].strip()
                if c.lower() == "city":
                    continue
                mp.setdefault(c, []).append(s)

    for k in mp:
        mp[k] = sorted(list(dict.fromkeys(mp[k])))
    return mp


def _load_addresses():
    mp = {}
    if ADDRESSES_CSV.exists():
        with open(ADDRESSES_CSV, encoding="utf-8") as f:
            r = csv.reader(f)
            for row in r:
                if len(row) < 3 or row[0].lower() == "city":
                    continue
                key = (row[0].strip(), row[1].strip())
                mp.setdefault(key, []).append(row[2].strip())

    for k in mp:
        mp[k] = sorted(list(dict.fromkeys(mp[k])))
    return mp


def _load_warehouses():
    items = []
    if WAREHOUSES_CSV.exists():
        with open(WAREHOUSES_CSV, encoding="utf-8") as f:
            r = csv.DictReader(f)
            for row in r:
                items.append({
                    "id": row.get("id", "").strip(),
                    "name": row.get("name", "").strip(),
                    "city": row.get("city", "").strip(),
                    "settlement": row.get("settlement", "").strip(),
                    "address": row.get("address", "").strip(),
                    "lat": row.get("lat", "").strip(),
                    "lon": row.get("lon", "").strip()
                })
    return items


# =====================================================================
#                            CONTROLLER
# =====================================================================
class DeliveryController:
    def __init__(self, table: TablePanel, sidebar: Sidebar):
        self.table = table
        self.sidebar = sidebar
        self.geocoder = Geocoder(CACHE_FILE)

        # DATA
        self.cities = _load_list_from_csv(CITIES_CSV)
        self.settlements_by_city = _load_settlements()
        self.addresses_by_pair = _load_addresses()
        self.warehouses = _load_warehouses()

        # ------------------ INIT UI ------------------

        # ✅ Склади
        warehouse_names = [w["name"] for w in self.warehouses]
        self.sidebar.warehouse_box.configure(values=warehouse_names)
        if warehouse_names:
            self.sidebar.warehouse_box.set(warehouse_names[0])

        # ✅ Міста
        self.sidebar.city_box.configure(values=self.cities)
        if self.cities:
            self.sidebar.city_box.set(self.cities[0])

        # ✅ CALLBACKS (CustomTkinter)
        self.sidebar.city_box.configure(command=self._on_city_change)
        self.sidebar.settlement_box.configure(command=self._on_settlement_change)

        # ✅ Первинне заповнення
        if self.cities:
            self._on_city_change(self.cities[0])

    # ------------------ REACTIVITY ------------------
    def _on_city_change(self, city: str):
        stls = self.settlements_by_city.get(city, [])
        self.sidebar.settlement_box.configure(values=stls)

        if stls:
            self.sidebar.settlement_box.set(stls[0])
            self._on_settlement_change(stls[0])
        else:
            self.sidebar.settlement_box.set("")
            self.sidebar.address_box.configure(values=[])
            self.sidebar.address_box.set("")

    def _on_settlement_change(self, stl: str):
        city = self.sidebar.city_box.get().strip()
        key = (city, stl)

        addrs = self.addresses_by_pair.get(key, [])
        self.sidebar.address_box.configure(values=addrs)
        self.sidebar.address_box.set(addrs[0] if addrs else "")

    # ------------------ UPDATE SPINBOX ------------------
    def _update_spin(self):
        count = len(self.table.tree.get_children())
        self.sidebar.vehicles_spin.config(to=max(1, count))

    # =====================================================================
    #                            ADD ROW
    # =====================================================================
    def add_row(self):
        w = self.sidebar.warehouse_box.get().strip()
        c = self.sidebar.city_box.get().strip()
        s = self.sidebar.settlement_box.get().strip()
        a = self.sidebar.address_box.get().strip()

        if not all([w, c, s, a]):
            messagebox.showerror("Помилка", "Заповніть усі поля адреси")
            return

        # Additional fields:
        try:
            weight = float(self.sidebar.weight_box.get())
        except:
            weight = 0.0

        try:
            volume = float(self.sidebar.volume_box.get())
        except:
            volume = 0.0

        tw_start = self.sidebar.tw_start_box.get().strip()
        tw_end = self.sidebar.tw_end_box.get().strip()

        try:
            service_min = float(self.sidebar.service_box.get())
        except:
            service_min = 10.0

        self.table.tree.insert(
            "",
            "end",
            values=(w, c, s, a, weight, volume, tw_start, tw_end, service_min)
        )

        self._update_spin()

    # =====================================================================
    #                           DELETE
    # =====================================================================
    def delete_selected(self):
        for iid in self.table.tree.selection():
            self.table.tree.delete(iid)
        self._update_spin()

    # =====================================================================
    #                           GEOCODING
    # =====================================================================
    def geocode_all(self):
        rows = self.table.tree.get_children()
        if not rows:
            messagebox.showinfo("Геокодинг", "Немає рядків у таблиці.")
            return

        updated = 0
        for iid in rows:
            w, c, s, a, *_ = self.table.tree.item(iid, "values")
            query = f"{a}, {s}, {c}, Ukraine"
            if self.geocoder.geocode(query):
                updated += 1

        save_cache(CACHE_FILE, self.geocoder.cache)
        messagebox.showinfo("Геокодинг", f"Геокодовано {updated} адрес. Кеш збережено.")

    # =====================================================================
    #                           CSV RELOAD
    # =====================================================================
    def reload_csvs(self):
        self.__init__(self.table, self.sidebar)
        messagebox.showinfo("OK", "CSV дані оновлено.")
