# -*- coding: utf-8 -*-
import json
import math
import threading
from pathlib import Path
from tkinter import messagebox

import folium
from folium import plugins

from app.core.geocoder import Geocoder
from app.core.router import route_with_fallback
from app.core.warehouse_loader import get_warehouse_coords

BASE_DIR = Path(__file__).resolve().parent.parent.parent
RESULTS_DIR = BASE_DIR / "results"
CACHE_FILE = BASE_DIR / "cache/locations.json"
TW_CACHE = BASE_DIR / "cache/routes_tw.json"

COLORS = [
    "red", "blue", "orange", "purple", "green",
    "black", "brown", "pink", "darkblue", "darkred"
]


def load_tw_cache():
    if TW_CACHE.exists():
        try:
            return json.loads(TW_CACHE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_tw_cache(cache: dict):
    TW_CACHE.parent.mkdir(parents=True, exist_ok=True)
    TW_CACHE.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")


def offset_coords(coords, offset=0.00012, vehicle_shift=0, angle_deg=40):
    """Зсув маршрутів щоб не накладались."""
    if vehicle_shift <= 0 or not coords:
        return coords
    dlat = offset * vehicle_shift * math.cos(math.radians(angle_deg))
    dlon = offset * vehicle_shift * math.sin(math.radians(angle_deg))
    return [(lat + dlat, lon + dlon) for (lat, lon) in coords]


def _open_map_async(path: Path):
    def _open():
        import webbrowser
        webbrowser.open(path.resolve().as_uri())
    threading.Thread(target=_open, daemon=True).start()


def parse_time_to_min(val, default_min):
    if val is None:
        return float(default_min)
    if isinstance(val, (int, float)):
        return float(val)

    s = str(val).strip()
    if not s:
        return float(default_min)

    if s.isdigit():
        return float(s)

    if ":" in s:
        try:
            hh, mm = s.split(":")
            return float(int(hh) * 60 + int(mm))
        except:
            return float(default_min)

    try:
        return float(s)
    except:
        return float(default_min)


class VRPTWController:
    """VRPTW — Vehicle Routing Problem with Time Windows."""

    def __init__(self, table, sidebar, status, map_panel=None):
        self.table = table
        self.sidebar = sidebar
        self.status = status
        self.map_panel = map_panel
        self.geocoder = Geocoder(CACHE_FILE)
        self.cache = load_tw_cache()
        self.max_work = 8 * 60  # хвилин роботи авто

    def solve_vrptw(self):

        rows = self.table.tree.get_children()
        if not rows:
            messagebox.showinfo("VRPTW", "Немає записів у таблиці.")
            return None

        # ----------------------------------------------------------------------
        # ОТРИМАННЯ ДАНИХ З ТАБЛИЦІ
        # ----------------------------------------------------------------------
        groups = {}
        for iid in rows:
            rowvals = self.table.tree.set(iid)

            wh   = rowvals.get("warehouse", "")
            city = rowvals.get("city", "")
            stl  = rowvals.get("settlement", "")
            addr = rowvals.get("address", "")

            tw_start = parse_time_to_min(rowvals.get("tw_start"), 0)
            tw_end   = parse_time_to_min(rowvals.get("tw_end"), 1440)
            serv     = parse_time_to_min(rowvals.get("service_min"), 10)

            query = f"{addr}, {stl}, {city}, Ukraine"
            loc = self.geocoder.geocode(query)
            if not loc:
                continue

            groups.setdefault(wh, []).append({
                "addr": addr,
                "loc": loc,
                "tw_start": tw_start,
                "tw_end": tw_end,
                "serv": serv
            })

        if not groups:
            messagebox.showwarning("VRPTW", "Адреси не геокодовані.")
            return None

        first_wh = next(iter(groups))
        depot_first = get_warehouse_coords(first_wh) or (50.45, 30.52)
        m = folium.Map(location=depot_first, zoom_start=6)

        stats = []
        total_routes = 0
        total_time = 0.0
        total_distance = 0.0

        try:
            vehicles_limit = max(1, int(self.sidebar.vehicles_spin.get()))
        except:
            vehicles_limit = 1

        # ----------------------------------------------------------------------
        # ОСНОВНИЙ АЛГОРИТМ VRPTW
        # ----------------------------------------------------------------------
        for wh, items in groups.items():

            depot = get_warehouse_coords(wh)
            if not depot:
                continue

            folium.Marker(
                depot,
                tooltip=f"Склад: {wh}",
                icon=folium.Icon(color="green", icon="home")
            ).add_to(m)

            # Сортуємо за кінцем time window
            unvisited = sorted(items, key=lambda x: x["tw_end"])
            vehicles_used = 0

            while unvisited and vehicles_used < vehicles_limit:

                vehicles_used += 1
                color = COLORS[(vehicles_used - 1) % len(COLORS)]

                day_start = min(s["tw_start"] for s in unvisited)
                cur_time = float(day_start)
                cur_pos = depot

                route_seq = []
                full_path = []
                veh_dist = 0.0
                veh_time = 0.0

                while True:
                    best = None
                    best_cost = None

                    for stop in unvisited:

                        origin_key = f"{round(cur_pos[0],5)},{round(cur_pos[1],5)}"
                        key = f"{origin_key}->{wh}|{stop['addr']}"

                        r = self.cache.get(key)
                        if not r:
                            r = route_with_fallback(cur_pos, stop["loc"])
                            if not r:
                                continue
                            self.cache[key] = r

                        travel = float(r["time_min"])
                        arrival = cur_time + travel

                        # не встигаємо у TW
                        if arrival > stop["tw_end"]:
                            continue

                        wait = max(0.0, stop["tw_start"] - arrival)
                        score = arrival + wait

                        if best_cost is None or score < best_cost:
                            best_cost = score
                            best = (stop, r, travel, arrival, wait)

                    if not best:
                        break

                    stop, r, travel, arrival, wait = best

                    next_time = arrival + wait + float(stop["serv"])

                    # перевищили робочий день авто
                    if next_time > self.max_work + day_start:
                        break

                    veh_time += travel
                    veh_dist += float(r["distance_km"])

                    full_path.extend(r["coords"] if not full_path else r["coords"][1:])
                    route_seq.append(stop)

                    cur_time = next_time
                    cur_pos = stop["loc"]
                    unvisited.remove(stop)

                if not route_seq:
                    break

                shifted = offset_coords(full_path, vehicle_shift=vehicles_used)

                folium.PolyLine(
                    shifted, color="black", weight=10, opacity=0.35
                ).add_to(m)

                line = folium.PolyLine(
                    shifted, color=color, weight=6, opacity=0.95
                ).add_to(m)

                plugins.PolyLineTextPath(
                    line, "➜", repeat=True, offset=10,
                    attributes={"fill": color, "font-weight": "bold", "font-size": "18"}
                ).add_to(m)

                for seq, stop in enumerate(route_seq, start=1):
                    tws = int(stop["tw_start"])
                    twe = int(stop["tw_end"])
                    folium.Marker(
                        stop["loc"],
                        tooltip=f"{seq}. {stop['addr']} [{tws}-{twe}]",
                        icon=folium.DivIcon(
                            html=f"<b style='color:{color};font-size:16px'>{seq}</b>"
                        )
                    ).add_to(m)

                stats.append({
                    "warehouse": wh,
                    "vehicle_id": vehicles_used,
                    "distance": round(veh_dist, 2),
                    "time": round(veh_time, 1),
                    "stops": len(route_seq)
                })

                total_routes += 1
                total_time += veh_time
                total_distance += veh_dist

        save_tw_cache(self.cache)

        # ----------------------------------------------------------------------
        # ЗБЕРЕЖЕННЯ МАПИ
        # ----------------------------------------------------------------------
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        out = RESULTS_DIR / "vrptw_routes.html"
        m.save(out)

        try:
            if self.map_panel:
                try:
                    self.map_panel.show_html_file(out, "VRPTW маршрути")
                except TypeError:
                    self.map_panel.show_html_file(out)
            else:
                _open_map_async(out)
        except:
            _open_map_async(out)

        self.status.set(
            f"✅ VRPTW виконано • авто: {total_routes} • відстань: "
            f"{round(total_distance,2)} км • час: {round(total_time,1)} хв"
        )

        return {
            "routes": stats,
            "distance": round(total_distance, 2),
            "time": round(total_time, 1),
            "vehicles": total_routes,
            "avg_eta": round(total_time / total_routes, 1) if total_routes else 0,
            "warehouses": list(groups.keys())
        }
