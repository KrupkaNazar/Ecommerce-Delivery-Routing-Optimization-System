# -*- coding: utf-8 -*-
from pathlib import Path
from tkinter import messagebox
import folium
from folium import plugins
import threading
import json
import math

from app.ui.table_panel import TablePanel
from app.ui.sidebar import Sidebar
from app.ui.statusbar import StatusBar

from app.core.geocoder import Geocoder
from app.core.clusterer import kmeans_cluster
from app.core.solver import solve_tsp_order
from app.core.router import route_with_fallback
from app.core.warehouse_loader import get_warehouse_coords
from app.core.baseline_solver import compute_baseline_routes

RESULTS_DIR = Path("results")
CACHE_FILE = Path("cache/locations.json")
VRP_CACHE = Path("cache/routes_vrp.json")

BASELINE_FILE = Path("cache/vrp_baseline_routes.json")
OPTIMIZED_FILE = Path("cache/optimized_routes_vrp.json")

COLORS = [
    "red", "blue", "orange", "purple", "green",
    "black", "brown", "pink", "darkblue", "darkred"
]


# ============================== CACHE ==============================

def load_vrp_cache() -> dict:
    if VRP_CACHE.exists():
        try:
            return json.loads(VRP_CACHE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_vrp_cache(cache: dict) -> None:
    VRP_CACHE.parent.mkdir(parents=True, exist_ok=True)
    VRP_CACHE.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")


# ============================== UTILS ==============================

def offset_coords(coords, offset: float = 0.00014, vehicle_shift: int = 0, angle_deg: float = 45.0):
    """Акуратно зміщує маршрути, якщо кілька авто їдуть по одній дорозі."""
    if vehicle_shift <= 0 or not coords:
        return coords[:]

    dlat = offset * vehicle_shift * math.cos(math.radians(angle_deg))
    dlon = offset * vehicle_shift * math.sin(math.radians(angle_deg))
    return [(lat + dlat, lon + dlon) for (lat, lon) in coords]


def _open_map_async(path: Path) -> None:
    """Обхід падіння webbrowser у Tkinter."""
    def _open():
        import webbrowser
        webbrowser.open(f"file://{path}")
    threading.Thread(target=_open, daemon=True).start()


def _cache_key_segment(warehouse: str, start_ll: tuple, dest_label: str) -> str:
    """Формує унікальний ключ кешу."""
    if start_ll is None:
        return f"{warehouse}|DEPOT|{dest_label}"
    slat, slon = start_ll
    return f"{warehouse}|{slat:.5f},{slon:.5f}|{dest_label}"


def _append_json_entry(path: Path, entry: dict):
    """Безпечно додає запис до JSON-списку (створює файл, якщо немає)."""
    data = []
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, list):
                data = []
        except Exception:
            data = []
    data.append(entry)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ============================== MAIN VRP CONTROLLER ==============================

class VRPController:
    def __init__(self, table: TablePanel, sidebar: Sidebar, map_panel, status: StatusBar):
        self.table = table
        self.sidebar = sidebar
        self.status = status
        self.geocoder = Geocoder(CACHE_FILE)
        self.vrp_cache = load_vrp_cache()

    # ====================================================================================
    #                                   VRP (K-means + TSP)
    # ====================================================================================
    def cluster_and_vrp(self):
        # ❌ РАНІШЕ ТУТ ОЧИЩАВСЯ BASELINE_FILE (write_text("[]"))
        # ЗАРАЗ НІЧОГО НЕ ЧИСТИМО — baseline накопичується через baseline_solver

        rows = self.table.tree.get_children()
        if not rows:
            messagebox.showinfo("VRP", "Немає записів у таблиці.")
            return None

        # ---- 1) ГРУПУВАННЯ ЗА СКЛАДОМ ----
        groups = {}

        for iid in rows:
            values = self.table.tree.item(iid, "values")
            if len(values) < 4:
                continue

            wh, city, stl, addr = values[:4]
            query = f"{addr}, {stl}, {city}, Ukraine"
            loc = self.geocoder.geocode(query)

            if loc:
                groups.setdefault(wh, []).append({
                    "address": addr,
                    "city": city,
                    "settlement": stl,
                    "loc": loc
                })

        if not groups:
            messagebox.showwarning("VRP", "Не вдалося геокодувати жодної адреси.")
            return None

        # ---- 2) СТВОРЮЄМО КАРТУ ----
        first_depot = None
        for wh in groups.keys():
            first_depot = get_warehouse_coords(wh)
            if first_depot:
                break

        m = folium.Map(location=first_depot or (50.45, 30.52), zoom_start=6)
        RESULTS_DIR.mkdir(exist_ok=True)

        total_routes = 0
        total_distance = 0.0
        total_time = 0.0
        stats_routes = []

        try:
            vehicles_global = max(1, int(self.sidebar.vehicles_spin.get()))
        except Exception:
            vehicles_global = 1

        # ====================================================================================
        #                         3) КОЖЕН СКЛАД — ОКРЕМИЙ VRP
        # ====================================================================================
        for wh_idx, (warehouse, items) in enumerate(groups.items()):
            depot = get_warehouse_coords(warehouse)
            if not depot:
                messagebox.showwarning("VRP", f"Немає координат складу: {warehouse}")
                continue

            folium.Marker(
                depot,
                tooltip=f"Склад: {warehouse}",
                icon=folium.Icon(color="green", icon="home")
            ).add_to(m)

            labels = [item["address"] for item in items]
            points = [item["loc"] for item in items]
            if not points:
                continue

            # ----------------------------------------------------------
            # BASELINE (ДО ОПТИМІЗАЦІЇ) — через окремий baseline_solver
            # ----------------------------------------------------------
            compute_baseline_routes(
                algorithm="vrp",
                warehouse=warehouse,
                depot=depot,
                points=points,
            )

            # ----------------------------------------------------------
            # КЛАСТЕРИЗАЦІЯ (VRP)
            # ----------------------------------------------------------
            k_local = min(vehicles_global, len(points))
            clusters = kmeans_cluster(points, k=k_local)

            # ====================================================================================
            #                           4) ОПРАЦЮВАННЯ КОЖНОГО АВТО
            # ====================================================================================
            for vehicle_id, idxs in clusters.items():
                color = COLORS[(wh_idx + vehicle_id) % len(COLORS)]

                cluster_pts = [points[i] for i in idxs]
                cluster_labels = [labels[i] for i in idxs]

                order = solve_tsp_order(depot, cluster_pts)
                if not order:
                    continue

                veh_dist = 0.0
                veh_time = 0.0
                full_path = []
                last_ll = None

                # ====================================================================================
                #                            5) ПОБУДОВА МАРШРУТУ
                # ====================================================================================
                for i in order:
                    dest_ll = cluster_pts[i]
                    dest_label = cluster_labels[i]

                    cache_key = _cache_key_segment(warehouse, last_ll or depot, dest_label)

                    if cache_key in self.vrp_cache:
                        r = self.vrp_cache[cache_key]
                    else:
                        start = last_ll or depot
                        r = route_with_fallback(start, dest_ll)

                        if not r:
                            last_ll = dest_ll
                            continue

                        self.vrp_cache[cache_key] = {
                            "coords": r["coords"],
                            "distance_km": float(r["distance_km"]),
                            "time_min": float(r["time_min"]),
                        }

                    if not full_path:
                        full_path.extend(r["coords"])
                    else:
                        full_path.extend(r["coords"][1:])

                    last_ll = dest_ll
                    veh_dist += float(r["distance_km"])
                    veh_time += float(r["time_min"])

                save_vrp_cache(self.vrp_cache)

                # ====================================================================================
                #                                6) МАЛЮВАННЯ НА МАПІ
                # ====================================================================================
                if full_path:
                    shifted = offset_coords(full_path, vehicle_shift=vehicle_id + 1)

                    # підкладка (тінь)
                    folium.PolyLine(
                        shifted, weight=10, color="black", opacity=0.35
                    ).add_to(m)

                    # основна лінія
                    line = folium.PolyLine(
                        shifted, weight=7, color=color, opacity=0.95
                    ).add_to(m)

                    # стрілки
                    plugins.PolyLineTextPath(
                        line, "➜", repeat=True, offset=10,
                        attributes={"fill": color, "font-weight": "bold", "font-size": "18"}
                    ).add_to(m)

                # НОМЕРИ ЗУПИНОК
                for seq, i in enumerate(order, start=1):
                    folium.Marker(
                        cluster_pts[i],
                        tooltip=f"[{warehouse}] Авто #{vehicle_id + 1} • {seq}. {cluster_labels[i]}",
                        icon=folium.DivIcon(
                            html=f'<div style="color:{color};font-weight:bold">{seq}</div>'
                        )
                    ).add_to(m)

                # ====================================================================================
                #                             7) СТАТИСТИКА
                # ====================================================================================
                stats_routes.append({
                    "warehouse": warehouse,
                    "vehicle": vehicle_id + 1,
                    "stops": len(order),
                    "distance": round(veh_dist, 2),
                    "time": round(veh_time, 1),
                })

                total_routes += 1
                total_distance += veh_dist
                total_time += veh_time

        # ====================================================================================
        #                                8) ЗБЕРЕГТИ КАРТУ
        # ====================================================================================
        html = RESULTS_DIR / "vrp_routes.html"
        m.save(html)
        _open_map_async(html.resolve())

        self.status.set(
            f"✅ Побудовано VRP • склади: {len(groups)} • авто: {total_routes} • "
            f"відстань: {round(total_distance, 2)} км • час: {round(total_time, 1)} хв"
        )

        # -----------------------------
        # Автоматичне збереження optimized_routes_vrp.json
        # append, а не перезапис
        # -----------------------------
        OPTIMIZED_FILE.parent.mkdir(parents=True, exist_ok=True)

        # читаємо попередні дані, якщо файл існує
        prev = []
        if OPTIMIZED_FILE.exists():
            try:
                prev = json.loads(OPTIMIZED_FILE.read_text(encoding="utf-8"))
                if not isinstance(prev, list):
                    prev = []
            except Exception:
                prev = []

        # додаємо нові маршрути
        new_entries = [
            {
                "warehouse": r["warehouse"],
                "distance_km": r["distance"],
                "time_min": r["time"],
            }
            for r in stats_routes
        ]
        prev.extend(new_entries)

        OPTIMIZED_FILE.write_text(
            json.dumps(prev, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

        return {
            "routes": stats_routes,
            "distance": round(total_distance, 2),
            "time": round(total_time, 1),
            "avg_eta": round(total_time / total_routes, 1) if total_routes else 0,
            "vehicles": total_routes,
            "warehouses": list(groups.keys()),
        }
