# -*- coding: utf-8 -*-
from pathlib import Path
from tkinter import messagebox
import folium
from folium import plugins
import threading
import json
import webbrowser

from app.ui.table_panel import TablePanel
from app.ui.sidebar import Sidebar
from app.ui.statusbar import StatusBar

from app.core.router import route_with_fallback
from app.core.geocoder import Geocoder
from app.core.warehouse_loader import get_warehouse_coords


RESULTS_DIR = Path("results")
CACHE_FILE = Path("cache/locations.json")
ROUTE_CACHE = Path("cache/routes.json")


# ✅ Єдина палітра кольорів (10 кольорів для всіх режимів)
COLORS = [
    "red", "blue", "orange", "purple", "green",
    "black", "brown", "pink", "darkblue", "darkred"
]


# ==============================
#   CACHE HELPERS
# ==============================
def load_route_cache() -> dict:
    if ROUTE_CACHE.exists():
        try:
            return json.loads(ROUTE_CACHE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_route_cache(cache: dict):
    ROUTE_CACHE.write_text(
        json.dumps(cache, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


# ==============================
#   MAIN CONTROLLER
# ==============================
class RouteController:
    """Controller responsible for building a single route."""

    def __init__(self, table: TablePanel, sidebar: Sidebar, map_panel, status: StatusBar, details_panel=None):
        self.table = table
        self.sidebar = sidebar
        self.map = map_panel
        self.status = status
        self.details_panel = details_panel

        self.geocoder = Geocoder(CACHE_FILE)
        self.route_cache = load_route_cache()

        RESULTS_DIR.mkdir(exist_ok=True)

    # ---------------------------------------------------------------------
    def build_single_route(self):
        """Build a route from warehouse → selected delivery address."""

        rows = self.table.tree.get_children()
        if not rows:
            messagebox.showinfo("Маршрут", "Немає записів у таблиці.")
            return

        sel = self.table.tree.selection()
        if not sel:
            messagebox.showinfo("Маршрут", "Оберіть доставку у таблиці.")
            return

        row_id = sel[0]
        wh_name, city, stl, addr = self.table.tree.item(row_id, "values")[:4]

        cache_key = f"{wh_name}|{city}|{stl}|{addr}"

        depot = get_warehouse_coords(wh_name)
        if not depot:
            messagebox.showerror("Маршрут", f"❌ Не знайдені координати складу: {wh_name}")
            return

        # ✅ Geocode destination
        query = f"{addr}, {stl}, {city}, Ukraine"
        dest = self.geocoder.geocode(query)
        if not dest:
            messagebox.showwarning("Маршрут", f"❌ Не вдалося геокодувати адресу:\n{query}")
            return

        # ✅ Cached?
        if cache_key in self.route_cache:
            route = self.route_cache[cache_key]
        else:
            route = route_with_fallback(depot, dest)
            if not route or "coords" not in route:
                messagebox.showerror("Маршрут", "❌ Не вдалося побудувати маршрут OSRM/Google.")
                return

            # Save
            self.route_cache[cache_key] = {
                "coords": route["coords"],
                "distance_km": float(route["distance_km"]),
                "time_min": float(route["time_min"])
            }
            save_route_cache(self.route_cache)

        coords = route["coords"]

        # ✅ MAP
        m = folium.Map(location=coords[0], zoom_start=14)

        # ✅ Warehouse
        folium.Marker(
            depot,
            tooltip=f"Склад: {wh_name}",
            icon=folium.Icon(color="green", icon="home")
        ).add_to(m)

        # ✅ Destination
        folium.Marker(
            dest,
            tooltip=f"Доставка: {addr}",
            icon=folium.Icon(color="blue", icon="truck")
        ).add_to(m)

        # ✅ Unified line rendering (as VRP / CVRP / VRPTW)
        color = COLORS[0]

        # Shadow/underlay
        folium.PolyLine(
            coords, color="black", weight=10, opacity=0.35
        ).add_to(m)

        # Main line
        line = folium.PolyLine(
            coords, color=color, weight=6, opacity=0.95
        ).add_to(m)

        # ✅ Direction arrows (same as VRP)
        plugins.PolyLineTextPath(
            line,
            "➜",
            repeat=True,
            offset=10,
            attributes={"fill": color, "font-weight": "bold", "font-size": "18"}
        ).add_to(m)

        # ✅ Save
        html = RESULTS_DIR / "single_route.html"
        m.save(html)

        threading.Thread(
            target=lambda: webbrowser.open(f"file://{html.resolve()}"),
            daemon=True
        ).start()

        # ✅ UI
        dist = float(route["distance_km"])
        time_min = float(route["time_min"])

        self.status.set(
            f"✅ Маршрут: {wh_name} → {addr} • {dist:.2f} км • {time_min:.0f} хв"
        )

        # ✅ Update Details Panel
        if self.details_panel:
            self.details_panel.update_info({
                "address": addr,
                "city": city,
                "settlement": stl,
                "distance": f"{dist:.2f}",
                "time": f"{time_min:.0f}"
            })
