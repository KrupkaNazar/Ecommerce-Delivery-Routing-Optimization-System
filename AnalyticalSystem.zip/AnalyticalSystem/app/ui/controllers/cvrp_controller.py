# -*- coding: utf-8 -*-
from pathlib import Path
from tkinter import messagebox
import folium, math, threading, json
from folium import plugins

from app.core.geocoder import Geocoder
from app.core.router import route_with_fallback
from app.core.warehouse_loader import get_warehouse_coords
from app.core.db.db import insert_vrp_result

RESULTS_DIR = Path("results")
CACHE_FILE = Path("cache/locations.json")
CVRP_CACHE = Path("cache/routes_cvrp.json")


# ======================================================================
#                            CACHE
# ======================================================================
def load_cvrp_cache():
    if CVRP_CACHE.exists():
        try:
            return json.loads(CVRP_CACHE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_cvrp_cache(cache: dict):
    CVRP_CACHE.write_text(
        json.dumps(cache, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


# ======================================================================
#                   SHIFT FOR PARALLEL LINES (no overlap)
# ======================================================================
def offset_coords(coords, offset=0.00012, vehicle_shift=0, angle=35):
    """Акуратний зсув ліній для різних авто (щоб не накладались візуально)."""
    if vehicle_shift == 0 or not coords:
        return coords
    dy = offset * vehicle_shift * math.cos(math.radians(angle))
    dx = offset * vehicle_shift * math.sin(math.radians(angle))
    return [(lat + dy, lon + dx) for (lat, lon) in coords]


def _open_map_async(path: Path):
    """Безпечне відкриття мапи у системному браузері (fallback)."""
    def _open():
        import webbrowser
        webbrowser.open(path.resolve().as_uri())
    threading.Thread(target=_open, daemon=True).start()


# ======================================================================
#                          CVRP CONTROLLER
# ======================================================================
class CVRPController:
    """Capacity VRP (вага/обʼєм)."""

    def __init__(self, table, sidebar, status, map_panel=None):
        self.table = table
        self.sidebar = sidebar
        self.status = status
        self.map_panel = map_panel
        self.geocoder = Geocoder(CACHE_FILE)
        self.cache = load_cvrp_cache()

        # допустимі параметри авто
        self.max_weight = 1000.0
        self.max_volume = 10.0

    # ==================================================================
    #                       MAIN CVRP FUNCTION
    # ==================================================================
    def solve_cvrp(self):

        rows = self.table.tree.get_children()
        if not rows:
            messagebox.showinfo("CVRP", "Немає даних у таблиці.")
            return None

        groups = {}

        # ---------------------------------------------------------------
        # 1) Збір нормалізованих даних
        # ---------------------------------------------------------------
        for iid in rows:
            row = self.table.tree.set(iid)   # словник колонок

            wh   = row.get("warehouse", "")
            city = row.get("city", "")
            stl  = row.get("settlement", "")
            addr = row.get("address", "")

            try:
                weight = float(row.get("weight", 20.0))
            except Exception:
                weight = 20.0

            try:
                volume = float(row.get("volume", 0.05))
            except Exception:
                volume = 0.05

            # геокодування
            query = f"{addr}, {stl}, {city}, Ukraine"
            loc = self.geocoder.geocode(query)
            if not loc:
                continue

            groups.setdefault(wh, []).append({
                "address": addr,
                "loc": loc,
                "weight": weight,
                "volume": volume
            })

        if not groups:
            messagebox.showwarning("CVRP", "Не вдалося згеокодувати жодну адресу.")
            return None

        # ---------------------------------------------------------------
        # 2) Створення карти
        # ---------------------------------------------------------------
        first_wh = next(iter(groups))
        depot_first = get_warehouse_coords(first_wh) or (50.45, 30.52)
        m = folium.Map(location=depot_first, zoom_start=7)

        total_dist = 0.0
        total_time = 0.0
        total_routes = 0
        stats_routes = []

        # ---------------------------------------------------------------
        # 3) CVRP по складах
        # ---------------------------------------------------------------
        for wh, items in groups.items():

            depot = get_warehouse_coords(wh)
            if not depot:
                continue

            folium.Marker(
                depot,
                tooltip=f"Склад: {wh}",
                icon=folium.Icon(color="green", icon="home")
            ).add_to(m)

            # -----------------------------------------------------------
            # 4) FIRST FIT BIN PACKING
            # -----------------------------------------------------------
            vehicles = [[]]
            cur_w = 0.0
            cur_v = 0.0

            for d in items:
                w = d["weight"]
                v = d["volume"]

                if cur_w + w > self.max_weight or cur_v + v > self.max_volume:
                    vehicles.append([])
                    cur_w = 0.0
                    cur_v = 0.0

                vehicles[-1].append(d)
                cur_w += w
                cur_v += v

            # -----------------------------------------------------------
            # 5) TSP + Routing
            # -----------------------------------------------------------
            for veh_id, cargo in enumerate(vehicles, start=1):

                if not cargo:
                    continue

                color = ["red", "blue", "purple", "orange", "pink", "black"][(veh_id - 1) % 6]

                unvisited = set(range(len(cargo)))
                order = []
                cur_pt = depot

                # nearest neighbor
                while unvisited:
                    nxt = min(
                        unvisited,
                        key=lambda i: (cur_pt[0] - cargo[i]["loc"][0]) ** 2 +
                                      (cur_pt[1] - cargo[i]["loc"][1]) ** 2
                    )
                    order.append(nxt)
                    cur_pt = cargo[nxt]["loc"]
                    unvisited.remove(nxt)

                full_path = []
                dist_sum = 0.0
                time_sum = 0.0
                last = depot
                stops_addresses = []

                for i in order:
                    addr = cargo[i]["address"]
                    loc = cargo[i]["loc"]
                    key = f"{wh}|{addr}"

                    r = self.cache.get(key)
                    if not r:
                        r = route_with_fallback(last, loc)
                        if r:
                            self.cache[key] = r
                            save_cvrp_cache(self.cache)

                    if not r:
                        last = loc
                        continue

                    if not full_path:
                        full_path.extend(r["coords"])
                    else:
                        full_path.extend(r["coords"][1:])

                    dist_sum += float(r["distance_km"])
                    time_sum += float(r["time_min"])

                    stops_addresses.append(addr)
                    last = loc

                # -------------------------------------------------------
                # Visual
                # -------------------------------------------------------
                shifted = offset_coords(full_path, vehicle_shift=veh_id)
                line = folium.PolyLine(shifted, color=color, weight=7).add_to(m)

                if self.map_panel is None:
                    plugins.PolyLineTextPath(
                        line, "➜", repeat=True, offset=10,
                        attributes={"fill": color, "font-weight": "bold", "font-size": "18"}
                    ).add_to(m)

                for seq, i in enumerate(order, start=1):
                    folium.Marker(
                        cargo[i]["loc"],
                        tooltip=f"[{wh}] Авто {veh_id} • {seq}. {cargo[i]['address']}",
                        icon=folium.DivIcon(
                            html=f"<b style='color:{color};font-size:14px'>{seq}</b>"
                        )
                    ).add_to(m)

                # -------------------------------------------------------
                # Save to DB
                # -------------------------------------------------------
                insert_vrp_result(
                    warehouse=wh,
                    vehicle=veh_id,
                    distance_km=round(dist_sum, 2),
                    time_min=round(time_sum, 1),
                    stops_count=len(order),
                    stops_labels=stops_addresses,
                    coords=full_path,
                    run_kind="cvrp"
                )

                stats_routes.append({
                    "warehouse": wh,
                    "vehicle_id": veh_id,
                    "distance": round(dist_sum, 2),
                    "time": round(time_sum, 1),
                    "stops": len(order)
                })

                total_routes += 1
                total_dist += dist_sum
                total_time += time_sum

        # ---------------------------------------------------------------
        # 6) SAVE MAP
        # ---------------------------------------------------------------
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        out = RESULTS_DIR / "cvrp_routes.html"
        m.save(out)

        if self.map_panel:
            try:
                self.map_panel.show_html_file(out, "CVRP маршрути")
            except TypeError:
                self.map_panel.show_html_file(out)
        else:
            _open_map_async(out)

        self.status.set(
            f"✅ CVRP виконано • авто: {total_routes} • відстань: {round(total_dist,2)} км"
        )

        return {
            "routes": stats_routes,
            "distance": round(total_dist, 2),
            "time": round(total_time, 1),
            "avg_eta": round(total_time / total_routes, 1) if total_routes else 0,
            "vehicles": total_routes,
            "warehouses": list(groups.keys())
        }
