# -*- coding: utf-8 -*-
from pathlib import Path
from tkinter import messagebox
from datetime import datetime
import threading
import webbrowser

import folium
from folium import Map, PolyLine, Marker
from folium import plugins

from app.ui.table_panel import TablePanel
from app.ui.sidebar import Sidebar
from app.ui.statusbar import StatusBar
from app.core.geocoder import Geocoder
from app.core.warehouse_loader import get_warehouse_coords
from app.core.router import route_with_fallback
from app.core.model import train_model, predict_eta

CACHE_FILE = Path("cache/locations.json")
HISTORY_CSV = Path("data/deliveries_history.csv")
RESULTS_DIR = Path("results")


class ETAController:
    def __init__(self, table: TablePanel, sidebar: Sidebar, status: StatusBar, map_panel=None):
        """Контролер ETA з виводом маршруту на мапу (стрілки, кольори, подвійний штрих)."""
        self.table = table
        self.sidebar = sidebar
        self.status = status
        self.map_panel = map_panel
        self.geocoder = Geocoder(CACHE_FILE)
        self.model_trained = False
        RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    # =====================================================================
    #                         НАВЧАННЯ МОДЕЛІ ETA
    # =====================================================================
    def train_eta(self):
        res = train_model(HISTORY_CSV)

        if not res:
            messagebox.showwarning("ETA", "Немає або замало історії у data/deliveries_history.csv.")
            return

        mae = res.get("mae_min", None)
        if mae is None:
            messagebox.showwarning("ETA", "Не вдалося обчислити MAE.")
            return

        self.model_trained = True
        self.status.set(f"✅ ETA навчено. Середня похибка ≈ {mae:.1f} хв")

    # =====================================================================
    #                             ПРОГНОЗ ETA
    # =====================================================================
    def predict_selected(self):
        sel = self.table.tree.selection()
        if not sel:
            messagebox.showinfo("ETA", "Виберіть рядок у таблиці.")
            return

        # ✅ Читаємо поля таблиці
        w_name, city, stl, addr = self.table.tree.item(sel[0], "values")[:4]

        # ✅ Координати складу
        depot = get_warehouse_coords(w_name)
        if not depot:
            messagebox.showerror(
                "ETA",
                f"Не знайдено координати складу '{w_name}' у файлі warehouses.csv."
            )
            return

        # ✅ Геокодуємо адресу доставки
        q = f"{addr}, {stl}, {city}, Ukraine"
        end = self.geocoder.geocode(q)
        if not end:
            messagebox.showwarning("ETA", f"Адресу '{q}' не геокодовано.")
            return

        # ✅ Маршрут
        r = route_with_fallback(depot, end)
        if not r:
            messagebox.showwarning("ETA", "Не вдалося отримати маршрут від складу до адреси.")
            return

        # ✅ Перевірка моделі
        if not self.model_trained:
            if predict_eta(None) is None:
                messagebox.showwarning("ETA", "Спочатку натисніть 'Навчити ETA'.")
                return

        # ✅ Формуємо фічі
        now = datetime.now()
        feats = {
            "distance_km": float(r["distance_km"]),
            "hour": now.hour,
            "dow": now.weekday(),
            "rain": 0.0,
            "temp": 15.0,
            "traffic_index": 1.0
        }

        # ✅ Прогноз ETA
        eta_min = predict_eta(feats)
        if eta_min is None:
            messagebox.showerror("ETA", "Модель ETA не повернула результат.")
            return

        # ✅ Текст
        dist = float(r["distance_km"])
        time_min = float(r["time_min"])
        msg = (
            f"Прогноз ETA: {eta_min:.1f} хв\n"
            f"Відстань: {dist:.2f} км\n"
            f"Маршрут: {r['src']}"
        )

        # ✅ В статусі — компактно
        self.status.set("✅ " + msg.replace("\n", " • "))

        # ✅ У pop-up — повністю
        messagebox.showinfo("ETA прогноз", msg)

        # ==================================================================
        #                    ПОКАЗ МАРШРУТУ НА МАПІ (стрілки + кольори)
        # ==================================================================
        try:
            html = RESULTS_DIR / "eta_route.html"
            coords = r["coords"]

            # Мапа — центруємося на складі
            m = Map(location=depot, zoom_start=12)

            # Подвійний штрих (тінь + основний колір)
            PolyLine(coords, color="black", weight=10, opacity=0.35).add_to(m)
            line = PolyLine(coords, color="blue", weight=7, opacity=0.95).add_to(m)

            # Стрілки напрямку вздовж маршруту
            plugins.PolyLineTextPath(
                line,
                "➜",
                repeat=True,
                offset=10,
                attributes={"fill": "blue", "font-weight": "bold", "font-size": "18"}
            ).add_to(m)

            # Маркери складу й адреси
            folium.Marker(
                depot,
                tooltip=f"Склад: {w_name}",
                icon=folium.Icon(color="green", icon="home")
            ).add_to(m)

            folium.Marker(
                end,
                tooltip=f"Адреса доставки: {addr}",
                icon=folium.Icon(color="red", icon="truck")
            ).add_to(m)

            # Збереження та показ
            m.save(html)

            if self.map_panel:
                # Підтримка двох сигнатур show_html_file
                try:
                    self.map_panel.show_html_file(str(html), "ETA маршрут")
                except TypeError:
                    self.map_panel.show_html_file(str(html))
            else:
                # Безпечне асинхронне відкриття у браузері (Win/Py 3.13)
                threading.Thread(
                    target=lambda: webbrowser.open(f"file://{html.resolve()}"),
                    daemon=True
                ).start()

        except Exception as e:
            print("ETA MAP ERROR:", e)
            # не критично — основна інформація показана у статусі та повідомленні
