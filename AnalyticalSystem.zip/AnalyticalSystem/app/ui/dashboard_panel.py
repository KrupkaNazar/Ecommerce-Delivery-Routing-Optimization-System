# -*- coding: utf-8 -*-
import customtkinter as ctk


class DashboardPanel(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, corner_radius=12)
        self.pack_propagate(False)

        # ---------------------------------------------
        # TITLE
        # ---------------------------------------------
        ctk.CTkLabel(
            self,
            text="📊 Загальна статистика доставки",
            font=("Segoe UI", 16, "bold")
        ).pack(pady=(8, 8))

        # ---------------------------------------------
        # METRICS BLOCK
        # ---------------------------------------------
        self.labels = {
            "warehouses": ctk.CTkLabel(self, text="Складів: —", font=("Segoe UI", 13)),
            "vehicles": ctk.CTkLabel(self, text="Автомобілів: —", font=("Segoe UI", 13)),
            "routes": ctk.CTkLabel(self, text="Маршрутів: —", font=("Segoe UI", 13)),
            "distance": ctk.CTkLabel(self, text="Загальна відстань: — км", font=("Segoe UI", 13)),
            "time": ctk.CTkLabel(self, text="Загальний час: — хв", font=("Segoe UI", 13)),
            "avg_eta": ctk.CTkLabel(self, text="Середній ETA: — хв", font=("Segoe UI", 13)),
            "min_eta": ctk.CTkLabel(self, text="Мін. ETA: — хв", font=("Segoe UI", 13)),
            "max_eta": ctk.CTkLabel(self, text="Макс. ETA: — хв", font=("Segoe UI", 13)),
        }

        for lbl in self.labels.values():
            lbl.pack(anchor="w", padx=14, pady=2)

    # ======================================================================
    #                          UPDATE STATISTICS
    # ======================================================================
    def update_stats(self, stats: dict | None):
        """
        Оновлює статистику VRP/CVRP/VRPTW.
        Очікуваний формат:
            stats = {
                "routes": [...],
                "vehicles": int,
                "warehouses": [...],
                "distance": float,
                "time": float,
                "avg_eta": float
            }
        """
        if not stats:
            self._reset()
            return

        routes = stats.get("routes", [])
        if not routes:
            self._reset()
            return

        # ✅ Склади
        warehouses = stats.get("warehouses") or list({r.get("warehouse") for r in routes})
        wh_count = len(warehouses)

        # ✅ Автомобілі
        vehicles = stats.get("vehicles", len(routes))

        # ✅ Кількість маршрутів
        total_routes = len(routes)

        # ✅ Загальна відстань
        total_distance = sum(r.get("distance", 0) for r in routes)

        # ✅ Загальний час
        total_time = sum(r.get("time", 0) for r in routes)

        # ✅ ETA
        all_eta = [r.get("time", 0) for r in routes]
        avg_eta = total_time / total_routes if total_routes else 0
        min_eta = min(all_eta) if all_eta else 0
        max_eta = max(all_eta) if all_eta else 0

        # ✅ UPDATE UI
        self.labels["warehouses"].configure(text=f"Складів: {wh_count}")
        self.labels["vehicles"].configure(text=f"Автомобілів: {vehicles}")
        self.labels["routes"].configure(text=f"Маршрутів: {total_routes}")

        self.labels["distance"].configure(text=f"Загальна відстань: {total_distance:.1f} км")
        self.labels["time"].configure(text=f"Загальний час: {total_time:.0f} хв")

        self.labels["avg_eta"].configure(text=f"Середній ETA: {avg_eta:.0f} хв")
        self.labels["min_eta"].configure(text=f"Мін. ETA: {min_eta:.0f} хв")
        self.labels["max_eta"].configure(text=f"Макс. ETA: {max_eta:.0f} хв")

    # ======================================================================
    #                               RESET
    # ======================================================================
    def _reset(self):
        """Скидає статистику при відсутності даних."""
        self.labels["warehouses"].configure(text="Складів: —")
        self.labels["vehicles"].configure(text="Автомобілів: —")
        self.labels["routes"].configure(text="Маршрутів: —")
        self.labels["distance"].configure(text="Загальна відстань: — км")
        self.labels["time"].configure(text="Загальний час: — хв")
        self.labels["avg_eta"].configure(text="Середній ETA: — хв")
        self.labels["min_eta"].configure(text="Мін. ETA: — хв")
        self.labels["max_eta"].configure(text="Макс. ETA: — хв")
