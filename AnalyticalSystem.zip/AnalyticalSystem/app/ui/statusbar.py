# -*- coding: utf-8 -*-
import customtkinter as ctk

class StatusBar(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master)
        self.label = ctk.CTkLabel(self, text="Готово.")
        self.label.pack(anchor="w", padx=10, pady=4)

    def set(self, text: str):
        self.label.configure(text=text)