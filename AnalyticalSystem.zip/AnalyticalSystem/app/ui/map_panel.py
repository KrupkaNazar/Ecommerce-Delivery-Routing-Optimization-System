# -*- coding: utf-8 -*-
import customtkinter as ctk
from pathlib import Path
import webbrowser

try:
    from tkhtmlview import HTMLLabel
    TKHTML_OK = True
except Exception:
    TKHTML_OK = False


class MapPanel(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, corner_radius=14)

        self.output_frame = ctk.CTkFrame(self, corner_radius=14)
        self.output_frame.pack(expand=True, fill="both", padx=16, pady=(6, 12))

        self.placeholder = ctk.CTkLabel(
            self.output_frame,
            text="Додайте адреси → Геокодуйте → Маршрут / VRP / CVRP / VRPTW",
            font=("Segoe UI", 14),
            justify="center"
        )
        self.placeholder.pack(expand=True)

    def show_html_file(self, html_path, subtitle: str = ""):
        """Показує карту: намагається вбудувати, але folium працює краще у браузері."""

        # ✅ Привести до Path
        if isinstance(html_path, str):
            html_path = Path(html_path)

        # Якщо файл не існує → вихід
        if not html_path.exists():
            webbrowser.open(f"file:///{html_path}")
            return

        # -------------------------------------------
        # ❗ ВАЖЛИВО: folium має JS → tkhtmlview НЕ підтримує JS!
        #           Тому всередині програми показ буде завжди НЕПРАВИЛЬНИЙ.
        #           Єдиний стабільний варіант — ВІДКРИТИ В БРАУЗЕРІ.
        # -------------------------------------------
        # Тому тут ми завжди відкриваємо у браузері.
        # -------------------------------------------
        webbrowser.open(f"file:///{html_path.resolve()}")

        # -------------------------------------------
        # ✅ Додатково — показуємо підпис (не карту)
        # -------------------------------------------
        for w in self.output_frame.winfo_children():
            w.destroy()

        ctk.CTkLabel(
            self.output_frame,
            text=f"Карта відкрита у браузері\n{subtitle}",
            font=("Segoe UI", 14)
        ).pack(expand=True, pady=20)
