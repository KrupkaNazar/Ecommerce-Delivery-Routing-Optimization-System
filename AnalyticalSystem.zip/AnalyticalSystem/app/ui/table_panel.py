# -*- coding: utf-8 -*-
import customtkinter as ctk
from tkinter import ttk


class TablePanel(ctk.CTkFrame):
    def __init__(self, master, width=1150, header_height=34):
        super().__init__(master, corner_radius=14, width=width)
        self.pack_propagate(False)

        self.on_row_changed = None

        # ================================================
        # ✅ Windows 11 TreeView стилізація
        # ================================================
        style = ttk.Style()
        style.theme_use("default")

        # Заголовок Win11
        style.configure(
            "Treeview.Heading",
            font=("Segoe UI", 11, "bold"),
            background="#e6e6e6",
            foreground="#000000",
            padding=(6, header_height - 24, 6, 6),
            relief="flat"
        )

        # Тіло таблиці
        style.configure(
            "Treeview",
            font=("Segoe UI", 11),
            rowheight=32,
            background="#f7f7f7",
            fieldbackground="#f7f7f7",
            borderwidth=0
        )

        # Смуга-виділення як Windows 11
        style.map(
            "Treeview",
            background=[("selected", "#cce1ff")],
            foreground=[("selected", "#000000")]
        )

        # Скролбар Win11
        style.configure(
            "Vertical.TScrollbar",
            gripcount=0,
            background="#d0d0d0",
            troughcolor="#f0f0f0",
            bordercolor="#f0f0f0",
            arrowcolor="#4a4a4a"
        )

        # ================================================
        # ✅ Обгортка таблиці
        # ================================================
        self.table_frame = ctk.CTkFrame(
            self,
            corner_radius=12,
            fg_color="#ffffff"
        )
        self.table_frame.pack(fill="both", expand=True, padx=16, pady=(12, 6))

        # ================================================
        # ✅ Стовпці таблиці
        # ================================================
        columns = (
            "warehouse",
            "city",
            "settlement",
            "address",
            "weight",
            "volume",
            "tw_start",
            "tw_end",
            "service_min"
        )

        self.tree = ttk.Treeview(
            self.table_frame,
            columns=columns,
            show="headings",
            style="Treeview"
        )

        # ------------------------------------------------
        # ✅ Заголовки
        # ------------------------------------------------
        self.tree.heading("warehouse", text="Склад")
        self.tree.column("warehouse", width=210)

        self.tree.heading("city", text="Місто")
        self.tree.column("city", width=160)

        self.tree.heading("settlement", text="Пункт")
        self.tree.column("settlement", width=180)

        self.tree.heading("address", text="Адреса")
        self.tree.column("address", width=300)

        # CVRP
        self.tree.heading("weight", text="Вага (кг)")
        self.tree.column("weight", width=80, anchor="center")

        self.tree.heading("volume", text="Обʼєм (м³)")
        self.tree.column("volume", width=80, anchor="center")

        # TW
        self.tree.heading("tw_start", text="TW Start (хв)")
        self.tree.column("tw_start", width=110, anchor="center")

        self.tree.heading("tw_end", text="TW End (хв)")
        self.tree.column("tw_end", width=110, anchor="center")

        self.tree.heading("service_min", text="Сервіс (хв)")
        self.tree.column("service_min", width=110, anchor="center")

        # ================================================
        # ✅ Скролбари
        # ================================================
        vsb = ttk.Scrollbar(self.table_frame, orient="vertical",
                            command=self.tree.yview)
        hsb = ttk.Scrollbar(self.table_frame, orient="horizontal",
                            command=self.tree.xview)

        self.tree.configure(yscroll=vsb.set, xscroll=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        self.table_frame.grid_columnconfigure(0, weight=1)
        self.table_frame.grid_rowconfigure(0, weight=1)

        # ================================================
        # ✅ Обробка вибору рядка
        # ================================================
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

    # ===================================================
    # ✅ Callback коли змінено рядок
    # ===================================================
    def _on_select(self, event):
        if self.on_row_changed:
            self.on_row_changed()

    # ===================================================
    # ✅ Додавання рядка
    # ===================================================
    def add_row(self, warehouse, city, settlement, address,
                weight="", volume="", tw_start="",
                tw_end="", service_min=""):

        def safe_num(x):
            try:
                return float(x)
            except:
                return x

        row = (
            warehouse,
            city,
            settlement,
            address,
            safe_num(weight),
            safe_num(volume),
            tw_start,
            tw_end,
            service_min
        )

        self.tree.insert("", "end", values=row)

    # ===================================================
    # ✅ Отримати вибраний рядок
    # ===================================================
    def get_selected(self):
        sel = self.tree.selection()
        if not sel:
            return None
        return self.tree.item(sel[0], "values")
