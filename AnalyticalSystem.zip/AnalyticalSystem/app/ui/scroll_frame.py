# -*- coding: utf-8 -*-
import customtkinter as ctk


class ScrollableFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)

        # ✅ Щоб ScrollableFrame ріс по висоті
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=0)

        # =========================================================
        # ✅ Коректний фон для Canvas
        # =========================================================
        fg = self._apply_appearance_mode(self.cget("fg_color"))
        canvas_bg = fg if isinstance(fg, str) else fg[1]

        # =========================================================
        # ✅ Canvas
        # =========================================================
        self.canvas = ctk.CTkCanvas(
            self,
            highlightthickness=0,
            bg=canvas_bg
        )
        self.canvas.grid(row=0, column=0, sticky="nsew")

        # =========================================================
        # ✅ Scrollbar
        # =========================================================
        self.scrollbar = ctk.CTkScrollbar(
            self,
            orientation="vertical",
            command=self.canvas.yview
        )
        self.scrollbar.grid(row=0, column=1, sticky="ns")

        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        # =========================================================
        # ✅ INNER — ТЕПЕР РОСТЕ ПО ВИСОТІ!
        # =========================================================
        self.inner = ctk.CTkFrame(self.canvas)
        self.inner.grid_rowconfigure(0, weight=1)
        self.inner.grid_columnconfigure(0, weight=1)

        self.inner_id = self.canvas.create_window(
            (0, 0),
            window=self.inner,
            anchor="nw"
        )

        # =========================================================
        # ✅ EVENTS
        # =========================================================
        self.inner.bind("<Configure>", self._on_frame_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)

        self.canvas.bind("<Enter>", self._bind_mousewheel)
        self.canvas.bind("<Leave>", self._unbind_mousewheel)

    # =============================================================
    # EVENTS
    # =============================================================
    def _on_frame_configure(self, event):
        """Оновлює область прокрутки."""
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, event):
        """Забезпечує повну ширину inner."""
        self.canvas.itemconfig(self.inner_id, width=event.width)

    # =============================================================
    # SCROLL CONTROL
    # =============================================================
    def _bind_mousewheel(self, event):
        self.canvas.bind_all("<MouseWheel>", self._scroll_windows_mac)
        self.canvas.bind_all("<Button-4>", self._scroll_linux)
        self.canvas.bind_all("<Button-5>", self._scroll_linux)

    def _unbind_mousewheel(self, event):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")

    # Windows / macOS
    def _scroll_windows_mac(self, event):
        self.canvas.yview_scroll(int(-event.delta / 120), "units")

    # Linux
    def _scroll_linux(self, event):
        if event.num == 4:
            self.canvas.yview_scroll(-1, "units")
        elif event.num == 5:
            self.canvas.yview_scroll(1, "units")
