# -*- coding: utf-8 -*-
import customtkinter as ctk
from pathlib import Path

from app.ui.scroll_frame import ScrollableFrame
from app.ui.sidebar import Sidebar
from app.ui.table_panel import TablePanel
from app.ui.statusbar import StatusBar
from app.ui.details_panel import DetailsPanel
from app.ui.dashboard_panel import DashboardPanel
from app.ui.map_panel import MapPanel

from app.ui.controllers.route_controller import RouteController
from app.ui.controllers.vrp_controller import VRPController
from app.ui.controllers.eta_controller import ETAController
from app.ui.controllers.delivery_controller import DeliveryController

from app.ui.controllers.cvrp_controller import CVRPController
from app.ui.controllers.vrptw_controller import VRPTWController
from app.charts import generate_reports
from app.core.cleaner import clear_all_caches

# Auto-create dirs
for d in (Path("data"), Path("results"), Path("cache")):
    d.mkdir(parents=True, exist_ok=True)


class AppWindow(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Delivery Analytics System — Desktop")
        self.geometry("1850x900")

        ctk.set_appearance_mode("System")
        ctk.set_default_color_theme("blue")

        # MAIN GRID
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=0)

        # ✅ LEFT SIDEBAR
        sidebar_scroll = ScrollableFrame(self)
        sidebar_scroll.grid(
            row=0,
            column=0,
            sticky="nsw",
            padx=(12, 6),
            pady=12
        )

        sidebar_scroll.grid_propagate(False)
        sidebar_scroll.configure(width=320)

        self.grid_rowconfigure(0, weight=1)
        sidebar_scroll.grid_rowconfigure(0, weight=1)

        sidebar_scroll.inner.grid_columnconfigure(0, weight=1)

        self.sidebar = Sidebar(sidebar_scroll.inner)
        self.sidebar.grid(row=0, column=0, sticky="nw")

        # ✅ RIGHT AREA
        right = ctk.CTkFrame(
            self,
            fg_color=("gray94", "gray16"),
            corner_radius=16
        )
        right.grid(
            row=0, column=1,
            sticky="nsew",
            padx=(0, 16), pady=(12, 12)
        )

        right.grid_columnconfigure(0, weight=1)
        right.grid_columnconfigure(1, weight=1)
        right.grid_rowconfigure(0, weight=3)
        right.grid_rowconfigure(1, weight=1)
        right.grid_rowconfigure(2, weight=1)
        right.grid_rowconfigure(3, weight=0)

        # TABLE
        self.table = TablePanel(right, width=1600)
        self.table.grid(
            row=0,
            column=0,
            columnspan=2,
            sticky="nsew",
            pady=(0, 10)
        )

        # MAP PANEL
        self.map_panel = MapPanel(right)
        self.map_panel.grid(
            row=1,
            column=0,
            columnspan=2,
            sticky="ew",
            padx=6,
            pady=(0, 10)
        )
        self.map_panel.configure(height=120)
        self.map_panel.grid_propagate(False)

        # VRP PANEL
        self.vrp_panel = DetailsPanel(right)
        self.vrp_panel.show_vrp_only()
        self.vrp_panel.title_vrp.configure(text="🚚 Маршрути доставки")
        self.vrp_panel.grid(
            row=2, column=0,
            sticky="nsew",
            padx=(0, 10), pady=6
        )

        # DELIVERY PANEL
        self.delivery_info = DetailsPanel(right)
        self.delivery_info.show_info_only()
        self.delivery_info.title_single.configure(text="📦 Обрана доставка")
        self.delivery_info.grid(
            row=2, column=1,
            sticky="nsew",
            padx=(10, 0), pady=6
        )

        # DASHBOARD
        self.dashboard = DashboardPanel(right)
        self.dashboard.grid(
            row=3,
            column=0,
            columnspan=2,
            sticky="ew",
            pady=(10, 6)
        )

        # STATUS BAR
        self.status = StatusBar(self)
        self.status.grid(row=1, column=0, columnspan=2, sticky="ew")

        # CONTROLLERS
        self.delivery = DeliveryController(self.table, self.sidebar)
        self.route = RouteController(
            self.table,
            self.sidebar,
            self.map_panel,
            self.status,
            self.delivery_info
        )
        self.vrp = VRPController(self.table, self.sidebar, self.map_panel, self.status)
        self.cvrp = CVRPController(self.table, self.sidebar, self.status, self.map_panel)
        self.vrptw = VRPTWController(self.table, self.sidebar, self.status, self.map_panel)
        self.eta = ETAController(self.table, self.sidebar, self.status, self.map_panel)

        # CALLBACKS
        self.sidebar.on_add = self.delivery.add_row
        self.sidebar.on_delete = self.delivery.delete_selected
        self.sidebar.on_geocode = self.delivery.geocode_all

        self.sidebar.on_route = self.route.build_single_route
        self.sidebar.on_vrp = self._run_vrp
        self.sidebar.on_cvrp = self._run_cvrp
        self.sidebar.on_vrptw = self._run_vrptw

        self.sidebar.on_eta_train = self.eta.train_eta
        self.sidebar.on_eta_predict = self.eta.predict_selected

        self.sidebar.on_charts = self._generate_charts
        self.sidebar.on_refresh = self.delivery.reload_csvs
        self.sidebar.on_clear_cache = self._clear_all_cache
        self.sidebar.on_theme_toggle = self._toggle_theme

        self.table.on_row_changed = self._update_selected_details

    # ============================================================
    # ✅ ОНОВЛЕНИЙ МЕТОД — РАХУЄ ВІДСТАНЬ ТА ЧАС
    # ============================================================
    def _update_selected_details(self):
        row = self.table.get_selected()
        if not row:
            self.delivery_info.update_info(None)
            return

        warehouse, city, settlement, addr = row[:4]

        # імпорти тут, щоб не виносити на рівень модуля
        from app.core.geocoder import Geocoder
        from app.core.warehouse_loader import get_warehouse_coords
        from app.core.router import route_with_fallback

        # кешований геокодер
        if not hasattr(self, "_inline_geocoder"):
            self._inline_geocoder = Geocoder(Path("cache/locations.json"))

        geocoder = self._inline_geocoder

        # координати складу
        depot = get_warehouse_coords(warehouse)
        if not depot:
            depot = geocoder.geocode(warehouse)

        # координати адреси
        q = ", ".join([p for p in [city, settlement, addr] if p])
        dest = geocoder.geocode(q)

        distance = "-"
        time_min = "-"

        if depot and dest:
            try:
                route = route_with_fallback(depot, dest)
                distance = f"{route.get('distance_km', 0):.1f}"
                time_min = f"{route.get('time_min', 0):.0f}"
            except Exception:
                pass

        # оновлення панелі
        self.delivery_info.update_info({
            "address": addr,
            "city": city,
            "settlement": settlement,
            "distance": distance,
            "time": time_min,
        })

    # ============================================================

    def _run_vrp(self):
        stats = self.vrp.cluster_and_vrp()
        if stats:
            self.vrp_panel.update_vrp_routes(stats)
            self.delivery_info.update_info(None)
            self.dashboard.update_stats(stats)

    def _run_cvrp(self):
        stats = self.cvrp.solve_cvrp()
        if stats:
            self.vrp_panel.update_vrp_routes(stats)
            self.delivery_info.update_info(None)
            self.dashboard.update_stats(stats)

    def _run_vrptw(self):
        stats = self.vrptw.solve_vrptw()
        if stats:
            self.vrp_panel.update_vrp_routes(stats)
            self.delivery_info.update_info(None)
            self.dashboard.update_stats(stats)

    def _generate_charts(self):
        ok = generate_reports()
        self.status.set(
            "✅ Графіки згенеровано (results/)"
            if ok else "⚠️ Немає даних у SQLite"
        )

    def _clear_all_cache(self):
        clear_all_caches()
        self.status.set("🗑️ Кеш очищено")

    def _toggle_theme(self, is_dark: bool):
        ctk.set_appearance_mode("Dark" if is_dark else "Light")
