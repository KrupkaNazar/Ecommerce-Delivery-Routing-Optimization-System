# -*- coding: utf-8 -*-
import customtkinter as ctk


class DetailsPanel(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(
            master,
            corner_radius=14,
            fg_color=("white", "#1f1f1f")
        )

        # ✅ Дозволяємо контейнеру рости
        self.grid_propagate(True)

        # ✅ Головна сітка
        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(3, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # ===== VRP SUMMARY =====
        self.title_vrp = ctk.CTkLabel(
            self,
            text="🚚 Маршрути доставки (VRP)",
            font=("Segoe UI", 15, "bold")
        )
        self.title_vrp.grid(row=0, column=0, sticky="w", padx=12, pady=(8, 4))

        self.vrp_text = ctk.CTkTextbox(
            self,
            fg_color="transparent",
            font=("Segoe UI", 12)
        )
        self.vrp_text.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))

        # ===== SINGLE DELIVERY =====
        self.title_single = ctk.CTkLabel(
            self,
            text="📦 Інформація про вибрану доставку",
            font=("Segoe UI", 15, "bold")
        )
        self.title_single.grid(row=2, column=0, sticky="w", padx=12)

        self.info_text = ctk.CTkTextbox(
            self,
            fg_color="transparent",
            font=("Segoe UI", 12)
        )
        self.info_text.grid(row=3, column=0, sticky="nsew", padx=10, pady=(0, 10))


    # =====================================================================
    # CONTROL METHODS
    # =====================================================================

    def hide_info_panel(self):
        self.title_single.grid_remove()
        self.info_text.grid_remove()

    def hide_vrp_panel(self):
        self.title_vrp.grid_remove()
        self.vrp_text.grid_remove()

    def show_vrp_only(self):
        self._restore_all()
        self.hide_info_panel()

    def show_info_only(self):
        self._restore_all()
        self.hide_vrp_panel()

    def _restore_all(self):
        # VRP
        self.title_vrp.grid(row=0, column=0, sticky="w", padx=12, pady=(8, 4))
        self.vrp_text.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))

        # INFO
        self.title_single.grid(row=2, column=0, sticky="w", padx=12)
        self.info_text.grid(row=3, column=0, sticky="nsew", padx=10, pady=(0, 10))

    # =====================================================================
    # ✅ VRP ROUTES SUMMARY (ОНОВЛЕНО, БЕЗ КРАШІВ)
    # =====================================================================
    def update_vrp_routes(self, stats):
        self.vrp_text.delete("1.0", "end")

        if not stats:
            self.vrp_text.insert("1.0", "⚠️ VRP ще не виконано")
            return

        routes = stats.get("route_details") or stats.get("routes") or stats

        if not routes:
            self.vrp_text.insert("1.0", "⚠️ Маршрутів не знайдено")
            return

        lines = []
        for r in routes:

            # ✅ Фікс: якщо r — рядок / int / list / що завгодно, але не dict
            if not isinstance(r, dict):
                lines.append(f"ℹ️ {r}")
                continue

            wh = r.get("warehouse", "—")
            car = r.get("vehicle_id") or r.get("vehicle", "—")
            dist = r.get("distance", 0)
            time = r.get("time", 0)

            stops = r.get("stops", [])
            if isinstance(stops, list):
                stops = len(stops)

            lines.append(
                f"🏭 {wh}\n"
                f"🚚 Авто #{car} | Зупинок: {stops}\n"
                f"🛣️ {dist:.1f} км   ⏱ {time:.0f} хв\n"
            )

        self.vrp_text.insert("1.0", "\n".join(lines))

    # =====================================================================
    # SINGLE DELIVERY INFO
    # =====================================================================
    def update_info(self, data: dict):
        self.info_text.delete("1.0", "end")

        if not data:
            self.info_text.insert("1.0", "👉 Оберіть доставку у таблиці")
            return

        text = f"""
📍 Адреса: {data.get('address', '—')}
🏙️ Місто: {data.get('city', '—')}
📦 Пункт: {data.get('settlement', '—')}

🛣️ Відстань: {data.get('distance', '—')} км
⏱️ Час: {data.get('time', '—')} хв
"""
        self.info_text.insert("1.0", text.strip() + "\n")
