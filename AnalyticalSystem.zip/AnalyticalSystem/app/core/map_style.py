# -*- coding: utf-8 -*-
import math

COLORS = ["red", "blue", "orange", "purple", "green",
          "black", "brown", "pink", "darkblue", "darkred"]

def offset_coords(coords, offset: float = 0.00014, vehicle_shift: int = 0, angle_deg: float = 45.0):
    if vehicle_shift <= 0 or not coords:
        return coords[:]
    dlat = offset * vehicle_shift * math.cos(math.radians(angle_deg))
    dlon = offset * vehicle_shift * math.sin(math.radians(angle_deg))
    return [(lat + dlat, lon + dlon) for (lat, lon) in coords]
