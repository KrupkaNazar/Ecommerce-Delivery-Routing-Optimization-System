# -*- coding: utf-8 -*-
import math
import requests

OSRM_URL = "https://router.project-osrm.org"

def _haversine_km(a, b):
    R = 6371.0088
    (lat1, lon1), (lat2, lon2) = a, b
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2-lat1)
    dl = math.radians(lon2-lon1)
    h = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dl/2)**2
    return 2*R*math.asin(math.sqrt(h))

def route_with_fallback(start, end):
    try:
        coords = f"{start[1]},{start[0]};{end[1]},{end[0]}"
        url = f"{OSRM_URL}/route/v1/driving/{coords}?overview=full&geometries=geojson"
        r = requests.get(url, timeout=10)
        if r.ok:
            data = r.json()
            if data.get("routes"):
                route = data["routes"][0]
                coords = [(y, x) for x, y in route["geometry"]["coordinates"]]
                dist_km = route["distance"]/1000.0
                time_min = route["duration"]/60.0
                return {"coords": coords, "distance_km": round(dist_km,2), "time_min": round(time_min,1), "src":"OSRM"}
    except Exception:
        pass

    dist_km = _haversine_km(start, end)
    time_min = (dist_km/40.0)*60.0
    return {"coords":[start, end], "distance_km": round(dist_km,2), "time_min": round(time_min,1), "src":"Haversine"}