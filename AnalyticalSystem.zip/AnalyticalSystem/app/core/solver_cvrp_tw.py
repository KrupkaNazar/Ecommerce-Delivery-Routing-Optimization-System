# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import List, Tuple, Dict, Optional
import math
from datetime import datetime, timedelta

LatLon = Tuple[float, float]

def haversine_km(a: LatLon, b: LatLon) -> float:
    from math import radians, sin, cos, asin, sqrt
    R = 6371.0088
    lat1, lon1 = map(radians, a)
    lat2, lon2 = map(radians, b)
    dlat, dlon = lat2-lat1, lon2-lon1
    h = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
    return 2*R*asin(sqrt(h))

def travel_time_min(a: LatLon, b: LatLon, speed_kmh: float) -> float:
    return 60.0 * (haversine_km(a,b) / max(1e-6, speed_kmh))

def _parse_hhmm(s: Optional[str]) -> Optional[datetime]:
    if not s: return None
    return datetime(2000,1,1,int(s[:2]),int(s[3:5]))

def _tw_ok(arrival: datetime, start: Optional[datetime], end: Optional[datetime]) -> Tuple[bool, float]:
    if start is None and end is None:
        return True, 0.0
    if start and arrival < start:
        wait = (start - arrival).total_seconds()/60.0
        return True, max(0.0, wait)
    if end and arrival > end:
        return False, 0.0
    return True, 0.0

def solve_cvrp_vrptw(
    depot: LatLon,
    stops: List[Dict],
    vehicles: int,
    cap_weight: float,
    cap_volume: float,
    speed_kmh: float = 40.0,
) -> List[Dict]:

    buckets = [ [] for _ in range(max(1, vehicles)) ]
    load_w = [0.0]*len(buckets)
    load_v = [0.0]*len(buckets)

    for i, s in enumerate(stops):
        w, v = float(s.get("weight",0)), float(s.get("volume",0))
        placed = False
        for b in range(len(buckets)):
            if load_w[b]+w <= cap_weight + 1e-6 and load_v[b]+v <= cap_volume + 1e-6:
                buckets[b].append(i)
                load_w[b] += w
                load_v[b] += v
                placed = True
                break
        if not placed:
            b = min(range(len(buckets)), key=lambda x: (load_w[x]/max(1e-6,cap_weight), load_v[x]/max(1e-6,cap_volume)))
            buckets[b].append(i)
            load_w[b] += w
            load_v[b] += v

    results = []
    for vid, idxs in enumerate(buckets, start=1):
        remaining = set(idxs)
        seq = []
        cur = depot
        now = datetime(2000,1,1,8,0)
        dist_km = 0.0
        time_min_total = 0.0

        while remaining:
            best = None
            best_gain = None
            for i in list(remaining):
                s = stops[i]
                nxt = (float(s["lat"]), float(s["lon"]))
                tt = travel_time_min(cur, nxt, speed_kmh)
                arrival = now + timedelta(minutes=tt)
                tw_s = _parse_hhmm(s.get("tw_start"))
                tw_e = _parse_hhmm(s.get("tw_end"))
                ok, wait = _tw_ok(arrival, tw_s, tw_e)
                if not ok: 
                    continue
                gain = tt + wait + float(s.get("service_min",0))
                if best_gain is None or gain < best_gain:
                    best_gain = gain
                    best = (i, nxt, tt, wait, s)

            if best is None:
                i = min(remaining, key=lambda j: haversine_km(cur, (stops[j]["lat"], stops[j]["lon"])))
                s = stops[i]
                nxt = (float(s["lat"]), float(s["lon"]))
                tt = travel_time_min(cur, nxt, speed_kmh)
                best = (i, nxt, tt, 0.0, s)

            i, nxt, tt, wait, s = best
            seq.append(i)
            dist_km += haversine_km(cur, nxt)
            time_min_total += tt + wait + float(s.get("service_min",0))
            now = now + timedelta(minutes=(tt + wait + float(s.get("service_min",0))))
            cur = nxt
            remaining.remove(i)

        coords = [depot] + [(stops[i]["lat"], stops[i]["lon"]) for i in seq]
        labels = [stops[i]["label"] for i in seq]
        results.append({
            "vehicle_id": vid,
            "order": seq,
            "coords": coords,
            "labels": labels,
            "distance_km": round(dist_km, 3),
            "time_min": round(time_min_total, 1),
        })

    return results
