# -*- coding: utf-8 -*-
def _dist(a, b):
    return ((a[0]-b[0])**2 + (a[1]-b[1])**2) ** 0.5

def solve_tsp_order(depot, points):
    n = len(points)
    if n == 0:
        return []
    if n == 1:
        return [0]
    unvisited = set(range(n))
    order = []
    cur_pt = depot
    while unvisited:
        nxt = min(unvisited, key=lambda i: _dist(cur_pt, points[i]))
        order.append(nxt)
        unvisited.remove(nxt)
        cur_pt = points[nxt]
    return order

def compute_baseline_distance_and_time(depot, points, speed_kmh=40):
    order = solve_tsp_order(depot, points)
    dist = 0.0
    cur = depot
    for idx in order:
        dist += _dist(cur, points[idx])
        cur = points[idx]
    time_min = dist / speed_kmh * 60
    return dist, time_min
