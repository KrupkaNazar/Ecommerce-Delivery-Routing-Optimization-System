# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import List, Tuple, Dict


def split_by_capacity(
    points: List[Tuple[float, float]],
    demands: List[float],
    capacity: float,
) -> List[List[int]]:
    n = len(points)
    unused = set(range(n))
    routes: List[List[int]] = []

    while unused:
        load = 0.0
        route: List[int] = []
        for i in list(unused):
            if load + demands[i] <= capacity:
                route.append(i)
                load += demands[i]
                unused.remove(i)
        if not route:
            i = min(unused, key=lambda j: demands[j])
            routes.append([i])
            unused.remove(i)
        else:
            routes.append(route)

    return routes
