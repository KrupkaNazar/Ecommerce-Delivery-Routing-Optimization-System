# -*- coding: utf-8 -*-
import json
import random
from pathlib import Path
from typing import List, Tuple, Dict, Any

from app.core.router import route_with_fallback


# baseline тільки для VRP
BASELINE_FILE = Path("cache/vrp_baseline_routes.json")


def _append_json_entry(path: Path, entry: Dict[str, Any]) -> None:
    data = []

    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, list):
                data = []
        except Exception:
            data = []

    data.append(entry)

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


def compute_baseline_routes(
    algorithm: str,
    warehouse: str,
    depot: Tuple[float, float],
    points: List[Tuple[float, float]],
) -> Dict[str, Any]:

    baseline_path = BASELINE_FILE

    if not depot or not points:
        entry = {
            "warehouse": warehouse,
            "distance_km": 0.0,
            "time_min": 0.0,
        }
        _append_json_entry(baseline_path, entry)
        return entry

    order = list(range(len(points)))
    random.shuffle(order)

    total_dist = 0.0
    total_time = 0.0
    last_ll = depot

    for idx in order:
        dest_ll = points[idx]

        seg = route_with_fallback(last_ll, dest_ll)
        if seg:
            total_dist += float(seg.get("distance_km", 0.0))
            total_time += float(seg.get("time_min", 0.0))

        last_ll = dest_ll

    entry = {
        "warehouse": warehouse,
        "distance_km": round(total_dist, 2),
        "time_min": round(total_time, 1),
    }

    _append_json_entry(baseline_path, entry)
    return entry
