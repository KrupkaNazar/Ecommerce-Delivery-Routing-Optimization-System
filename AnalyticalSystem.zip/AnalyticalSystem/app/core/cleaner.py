# -*- coding: utf-8 -*-
from pathlib import Path
import os
import json

CACHE_DIR = Path("cache")
FILES = [
    "locations.json",
    "routes.json",
    "routes_vrp.json",
    "eta_model.pkl",
    "optimized_routes_vrp.json",
    "vrp_baseline_routes.json",
]

def clear_all_caches():
    CACHE_DIR.mkdir(exist_ok=True)

    removed = []

    for fname in FILES:
        f = CACHE_DIR / fname
        if f.exists():
            try:
                if f.suffix == ".json":
                    f.write_text("{}", encoding="utf-8")
                else:
                    os.remove(f)
                removed.append(fname)
            except Exception as e:
                print(f"Cannot remove {fname}: {e}")

    return removed
