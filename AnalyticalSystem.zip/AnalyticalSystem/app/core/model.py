# -*- coding: utf-8 -*-
import pandas as pd
from pathlib import Path
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error

_model = None
_features = ["distance_km", "hour", "dow", "rain", "temp", "traffic_index"]

def train_model(csv_path: Path):
    global _model
    if not csv_path.exists():
        return None
    df = pd.read_csv(csv_path)
    required_cols = set(_features + ["eta_min"])
    if not required_cols.issubset(df.columns):
        return None
    X = df[_features]
    y = df["eta_min"]
    Xtr, Xval, ytr, yval = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestRegressor(n_estimators=200, random_state=42)
    model.fit(Xtr, ytr)
    preds = model.predict(Xval)
    mae = mean_absolute_error(yval, preds)
    _model = model
    return {"mae_min": float(mae), "n_train": len(Xtr), "n_val": len(Xval)}

def predict_eta(feats: dict):
    global _model
    if _model is None:
        return None
    import pandas as pd
    X = pd.DataFrame([feats])[_features]
    val = float(_model.predict(X)[0])
    return val