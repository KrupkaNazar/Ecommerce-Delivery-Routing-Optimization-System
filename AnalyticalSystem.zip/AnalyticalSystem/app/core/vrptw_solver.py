# -*- coding: utf-8 -*-
from __future__ import annotations
from typing import List, Tuple


def build_order_with_time_windows(
    depot: Tuple[float, float],
    points: List[Tuple[float, float]],
    tw: List[Tuple[int, int]],
    travel_time: callable,
    service_min: int = 5,
) -> List[int]:
    n = len(points)
    remaining = set(range(n))
    order: List[int] = []
    cur_time = 0
    cur_pos = depot

    while remaining:
        feasible = []
        for i in remaining:
            tt = travel_time(cur_pos, points[i])
            arr = cur_time + tt
            start, end = tw[i]
            begin_service = max(arr, start)
            finish = begin_service + service_min
            if finish <= end:
                feasible.append((finish, tt, i, begin_service))
        if not feasible:
            i = min(remaining, key=lambda j: travel_time(cur_pos, points[j]))
            order.append(i)
            cur_time += travel_time(cur_pos, points[i]) + service_min
            cur_pos = points[i]
            remaining.remove(i)
        else:
            finish, tt, i, begin_service = min(feasible)
            order.append(i)
            cur_time = finish
            cur_pos = points[i]
            remaining.remove(i)

    return order
