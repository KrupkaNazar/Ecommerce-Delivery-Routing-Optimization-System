import tkinter as tk
from tkinter import messagebox

def msg_error(title, text):
    root = tk.Toplevel()
    root.withdraw()
    messagebox.showerror(title, text, parent=root)
    root.destroy()

def msg_info(title, text):
    root = tk.Toplevel()
    root.withdraw()
    messagebox.showinfo(title, text, parent=root)
    root.destroy()

def msg_warn(title, text):
    root = tk.Toplevel()
    root.withdraw()
    messagebox.showwarning(title, text, parent=root)
    root.destroy()
