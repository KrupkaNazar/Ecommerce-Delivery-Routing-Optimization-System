# -*- coding: utf-8 -*-
from sklearn.cluster import KMeans
import numpy as np

def kmeans_cluster(points, k=1):
    if k <= 1 or len(points) <= 1:
        return {0: list(range(len(points)))}
    X = np.array(points)
    km = KMeans(n_clusters=min(k, len(points)), n_init=10, random_state=42)
    labels = km.fit_predict(X)
    clusters = {}
    for idx, lab in enumerate(labels):
        clusters.setdefault(lab, []).append(idx)
    remap = {lab:i for i, lab in enumerate(sorted(clusters.keys()))}
    return {remap[lab]: idxs for lab, idxs in clusters.items()}