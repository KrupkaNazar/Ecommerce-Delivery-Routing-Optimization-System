# -*- coding: utf-8 -*-
import sqlite3
import json
from pathlib import Path

DB_PATH = Path("data/app.db")
SCHEMA_FILE = Path("app/core/db/schema.sql")


# ---------------------------
# Підключення до бази
# ---------------------------
def get_conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


# ---------------------------
# Ініціалізація схеми
# ---------------------------
def init_db():
    """Створює таблиці за схемою schema.sql"""
    if not SCHEMA_FILE.exists():
        raise FileNotFoundError(f"❌ Відсутній файл схеми БД: {SCHEMA_FILE}")

    with get_conn() as c, open(SCHEMA_FILE, "r", encoding="utf-8") as f:
        sql = f.read()
        c.executescript(sql)


# ================================================================
# INSERT / UPSERT функції
# ================================================================

# ---------------------------
# Склади
# ---------------------------
def upsert_warehouse(name: str, lat: float, lon: float):
    with get_conn() as c:
        c.execute("""
            INSERT INTO warehouses(name, lat, lon)
            VALUES (?, ?, ?)
            ON CONFLICT(name)
            DO UPDATE SET lat = excluded.lat,
                          lon = excluded.lon;
        """, (name, lat, lon))


# ---------------------------
# Доставка (факт доставки)
# ---------------------------
def insert_delivery(row: dict):
    keys = (
        "warehouse", "city", "settlement", "address",
        "lat", "lon",
        "weight", "volume",
        "tw_start", "tw_end",
        "service_min"
    )
    vals = tuple(row.get(k) for k in keys)

    with get_conn() as c:
        c.execute(f"""
            INSERT INTO deliveries ({",".join(keys)})
            VALUES ({",".join(["?"]*len(keys))})
        """, vals)


# ---------------------------
# Запис одиночного маршруту
# ---------------------------
def insert_route(warehouse: str, address: str,
                 distance_km: float, time_min: float,
                 coords: list):
    with get_conn() as c:
        c.execute("""
            INSERT INTO routes(warehouse, address, distance_km, time_min, coords_json)
            VALUES (?, ?, ?, ?, ?)
        """, (
            warehouse, address,
            distance_km, time_min,
            json.dumps(coords, ensure_ascii=False)
        ))


# ---------------------------
# Результати VRP / CVRP / VRPTW
# ---------------------------
def insert_vrp_result(warehouse: str, vehicle: int,
                      distance_km: float, time_min: float,
                      stops_count: int, stops_labels: list,
                      coords: list, run_kind: str):
    with get_conn() as c:
        c.execute("""
            INSERT INTO vrp_results
            (warehouse, vehicle, distance_km, time_min, stops_count,
             stops_labels_json, coords_json, run_kind)
            VALUES (?,?,?,?,?,?,?,?)
        """, (
            warehouse, vehicle, distance_km, time_min, stops_count,
            json.dumps(stops_labels, ensure_ascii=False),
            json.dumps(coords, ensure_ascii=False),
            run_kind
        ))



# ================================================================
# READ-функції для аналітики / UI
# ================================================================

# ---------------------------
# Останні запуски VRP
# ---------------------------
def load_vrp_summary(limit: int = 200):
    """Повертає історію запусків VRP/CVRP/VRPTW."""
    with get_conn() as c:
        cur = c.execute(f"""
            SELECT created_at, run_kind, warehouse, vehicle,
                   distance_km, time_min, stops_count
            FROM vrp_results
            ORDER BY created_at DESC
            LIMIT {limit};
        """)
        return cur.fetchall()


# ---------------------------
# Завантаження одиночних маршрутів
# ---------------------------
def load_route_history(limit: int = 200):
    with get_conn() as c:
        cur = c.execute(f"""
            SELECT created_at, warehouse, address,
                   distance_km, time_min
            FROM routes
            ORDER BY created_at DESC
            LIMIT {limit}
        """)
        return cur.fetchall()
