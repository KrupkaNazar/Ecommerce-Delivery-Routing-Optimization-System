-- -------------------------------------
--  Warehouses
-- -------------------------------------
CREATE TABLE IF NOT EXISTS warehouses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  lat REAL NOT NULL,
  lon REAL NOT NULL
);

-- -------------------------------------
--  Deliveries (вхідні замовлення)
-- -------------------------------------
CREATE TABLE IF NOT EXISTS deliveries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  warehouse TEXT NOT NULL,
  city TEXT,
  settlement TEXT,
  address TEXT NOT NULL,
  lat REAL,
  lon REAL,
  weight REAL DEFAULT 0,     -- кг
  volume REAL DEFAULT 0,     -- м^3
  tw_start TEXT,             -- 'HH:MM' (часові вікна)
  tw_end   TEXT,             -- 'HH:MM'
  service_min REAL DEFAULT 0 -- час обслуговування, хв
);

-- -------------------------------------
--  Single routes (Manual / One-to-one)
-- -------------------------------------
CREATE TABLE IF NOT EXISTS routes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  warehouse TEXT,
  address TEXT,
  distance_km REAL,
  time_min REAL,
  coords_json TEXT
);

-- -------------------------------------
--  VRP results (зведення: VRP, CVRP, VRPTW)
-- -------------------------------------
CREATE TABLE IF NOT EXISTS vrp_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  run_kind TEXT DEFAULT 'vrp',   -- ✅ vrp / cvrp / vrptw
  warehouse TEXT,
  vehicle INTEGER,
  distance_km REAL,
  time_min REAL,
  stops_count INTEGER,
  stops_labels_json TEXT,
  coords_json TEXT
);
