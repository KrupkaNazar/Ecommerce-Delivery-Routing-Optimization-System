# -*- coding: utf-8 -*-
from .db import get_conn

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS deliveries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  warehouse TEXT, city TEXT, settlement TEXT, address TEXT,
  weight REAL DEFAULT 0,
  tw_start INTEGER, tw_end INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS routes_single (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  warehouse TEXT, address TEXT,
  distance_km REAL, time_min REAL,
  coords_json TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vrp_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT,                  -- 'VRP' | 'CVRP' | 'VRPTW'
  warehouses_json TEXT,
  vehicles INTEGER,
  total_distance REAL,
  total_time REAL,
  routes_json TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS eta_models (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  version TEXT,
  metrics_json TEXT,
  blob BLOB,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
"""

def ensure_schema():
    with get_conn() as c:
        c.executescript(SCHEMA_SQL)
