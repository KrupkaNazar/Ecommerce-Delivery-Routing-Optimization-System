# -*- coding: utf-8 -*-
import json
from pathlib import Path
import time
import requests

USER_AGENT = "DeliveryAnalyticsSystem/1.0"

def load_cache(path: Path):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def save_cache(path: Path, cache: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")

class Geocoder:
    def __init__(self, cache_path: Path):
        self.cache_path = cache_path
        self.cache = load_cache(cache_path)

    def geocode(self, query: str):
        if query in self.cache and self.cache[query].get("lat") is not None:
            c = self.cache[query]
            return (c["lat"], c["lon"])

        url = "https://nominatim.openstreetmap.org/search"
        params = {"q": query, "format":"jsonv2", "limit":1}
        headers = {"User-Agent": USER_AGENT}
        try:
            r = requests.get(url, params=params, headers=headers, timeout=10)
            if r.ok and r.json():
                item = r.json()[0]
                lat, lon = float(item["lat"]), float(item["lon"])
                self.cache[query] = {"lat": lat, "lon": lon}
                save_cache(self.cache_path, self.cache)
                time.sleep(1)
                return (lat, lon)
        except Exception:
            return None
        return None