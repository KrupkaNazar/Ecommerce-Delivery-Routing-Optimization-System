import csv
from pathlib import Path

WAREHOUSES_FILE = Path("data/warehouses.csv")

def get_warehouse_coords(name: str):
    if not WAREHOUSES_FILE.exists():
        return None

    with open(WAREHOUSES_FILE, encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row.get("name") == name:
                try:
                    return (float(row["lat"]), float(row["lon"]))
                except:
                    return None
    return None
