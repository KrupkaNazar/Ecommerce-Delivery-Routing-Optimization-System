from app.core.db.db import init_db

init_db()
print("✅ Database schema updated!")
