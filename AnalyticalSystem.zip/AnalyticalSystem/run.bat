@echo off
chcp 65001 >nul
title Delivery Analytics System

cd /d "%~dp0"

:: Проверка venv
IF NOT EXIST venv (
    echo Создание окружения...
    python -m venv venv
)

echo Активация...
call venv\Scripts\activate.bat

echo Установка библиотек (это может занять минуту)...
python -m pip install --upgrade pip

:: Устанавливаем всё самое важное сразу
python -m pip install customtkinter matplotlib pandas numpy

if exist requirements.txt (
    python -m pip install -r requirements.txt
)

echo Запуск приложения...
python launch.py

echo Приложение завершило работу.
pause
